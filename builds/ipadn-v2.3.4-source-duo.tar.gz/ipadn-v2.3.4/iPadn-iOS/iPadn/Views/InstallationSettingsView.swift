import SwiftUI
import UniformTypeIdentifiers

struct InstallationSettingsView: View {
    // Encode the fragment explicitly because iOS 16 URL parsing requires it.
    static let helpURL = URL(string: "https://github.com/mengangs/ipadn#%E5%AE%89%E8%A3%85%E4%B8%8B%E8%BD%BD%E7%9A%84%E5%BA%94%E7%94%A8")

    @EnvironmentObject private var store: ToolStore
    @Environment(\.openURL) private var openURL
    @State private var importing = false
    @State private var deferredCertificateData: Data?
    @State private var deferredImportIssue: String?
    @State private var hasLocalProfile = false
    @State private var replacingCertificate = false
    @State private var certificateData: Data?
    @State private var password = ""
    @State private var certificateName = Self.notImported
    /// Stored value, not display text: the certificate is either present or not.
    nonisolated private static let notImported = "未导入"
    @State private var issue: String?
    @State private var busy = false
    /// Which action is running, shown with a spinner on its own row.
    @State private var working: Action?
    @State private var checkTask: Task<Void, Never>?
    private enum Action { case create, profile, check, connection }
    /// What the file picker is importing.
    private enum ImportKind { case certificate, pairingFile }
    @State private var importKind = ImportKind.certificate
    @State private var hasPairingFile = NativeInstaller.hasPairingFile
    @State private var removingPairingFile = false
    @StateObject private var pairing = OnDevicePairing()
    @State private var showingPairingGuide = false
    @Environment(\.scenePhase) private var scenePhase
    private enum Method: Hashable { case native, automatic, localCertificate, proxy }
    private var method: Binding<Method> {
        Binding(get: {
            store.settings.usesNativeInstallation ? .native
                : store.settings.automaticInstallation ? .automatic
                : store.settings.localInstallation ? .localCertificate : .proxy
        }, set: { value in
            // The other choices are kept, so leaving native returns to them.
            store.settings.nativeInstallation = value == .native
            guard value != .native else { return }
            store.settings.automaticInstallation = value == .automatic
            if value != .automatic { store.settings.localInstallation = value == .localCertificate }
        })
    }
    var body: some View {
        Form {
            // Segments use short names so four of them fit in every
            // language; the section below each one gives the full name.
            Section {
                Picker("安装方式", selection: method) {
                    Text("安装方式·一键").tag(Method.automatic)
                    if NativeInstaller.isAvailable { Text("安装方式·原生").tag(Method.native) }
                    Text("安装方式·证书").tag(Method.localCertificate)
                    Text("安装方式·代理").tag(Method.proxy)
                }.pickerStyle(.segmented).accessibilityIdentifier("installation.method")
            }
            if store.settings.usesNativeInstallation {
                Section {
                    if !NativeInstaller.isSystemVersionSupported {
                        InlineIssue(message: AppText.text("原生安装需要 iOS 17.4 及以上系统。当前系统请改用「一键安装」或「本机证书」。"))
                    }
                    Label("App Store 能识别并更新安装的应用", systemImage: "checkmark.seal")
                    Label("可以直接覆盖 App Store 安装的应用，数据保留", systemImage: "arrow.triangle.2.circlepath")
                    LabeledContent("配对文件", value: hasPairingFile ? AppText.text("已导入") : AppText.text("未导入"))
                    if OnDevicePairing.isSupported {
                        Button { pairing.start(); showingPairingGuide = true } label: {
                            actionLabel(hasPairingFile ? "重新配对" : "在本机配对", systemImage: "iphone.radiowaves.left.and.right", running: pairing.phase.isActive)
                        }
                        .disabled(pairing.phase.isActive).accessibilityIdentifier("installation.pair-on-device")
                    }
                    Button("导入配对文件", systemImage: "square.and.arrow.down") { importPairingFile() }
                        .disabled(busy || !NativeInstaller.isSystemVersionSupported)
                        .accessibilityIdentifier("installation.pairing-file")
                    Button { checkConnection() } label: { actionLabel("检查连接", systemImage: "point.3.connected.trianglepath.dotted", action: .connection) }
                        .disabled(busy || !hasPairingFile || !NativeInstaller.isSystemVersionSupported).accessibilityIdentifier("installation.native-check")
                    if hasPairingFile {
                        Button("移除配对文件", systemImage: "trash", role: .destructive) { removingPairingFile = true }
                    }
                } header: { Text("原生安装") } footer: {
                    if OnDevicePairing.isSupported {
                        Text("通过系统自带的安装服务安装，效果与用电脑安装相同。\n1. 点按「在本机配对」，然后打开「设置 › 隐私与安全性 › 开发者模式」，点按「与 iPadn 配对」，输入 iPadn 显示的配对码。看不到开发者模式时，需要先在该页面开启并重启设备。\n2. 安装前打开 LocalDevVPN 并点按连接，或使用已配置好环回路由的代理工具。\n修改锁屏密码、系统还原后需要重新配对。安装包不会离开这台设备。")
                    } else {
                        Text("通过系统自带的安装服务安装，效果与用电脑安装相同。需要两样东西：\n1. 从 App Store 安装 LocalDevVPN，安装前在其中点按连接。它与其他代理或 VPN 不能同时开启。\n2. 在电脑上用 idevice_pair 为这台设备生成「远程配对（RPPairing）」文件，放进「文件 › 我的 iPhone › iPadn」后点按「导入配对文件」，也可以从其他位置选取。系统更新或还原后可能需要重新生成。\n安装包不会离开这台设备。")
                    }
                }
                if pairing.phase != .idle, !showingPairingGuide {
                    Section {
                        PairingStatusRow(phase: pairing.phase)
                        if pairing.phase.isActive {
                            Button("取消配对", role: .destructive) { pairing.cancel() }
                                .frame(maxWidth: .infinity)
                                .accessibilityIdentifier("installation.pairing-cancel")
                        }
                    }
                }
            } else if store.settings.automaticInstallation {
                Section {
                    Label("无需描述文件或证书", systemImage: "checkmark.seal")
                    Label("安装包不会离开这台设备", systemImage: "iphone")
                } header: { Text("一键安装（推荐）") } footer: {
                    Text("安装时需要联网。安装完成前请勿退出 iPadn。使用代理工具时，请为 api.palera.in 添加直连（DIRECT）规则。")
                }
            } else if store.settings.localInstallation {
                Section {
                    TextField("服务器地址", text: $store.settings.localInstallHost)
                        .textInputAutocapitalization(.never).autocorrectionDisabled().keyboardType(.URL)
                    LabeledContent("证书", value: certificateName == Self.notImported ? AppText.text("未导入") : certificateName)
                    Button {
                        if certificateName == Self.notImported { createLocalCertificate() }
                        else { replacingCertificate = true }
                    } label: { actionLabel("创建证书", systemImage: "lock.shield", action: .create) }
                    .disabled(busy).accessibilityIdentifier("installation.create-certificate")
                    if hasLocalProfile {
                        Button { installProfile() } label: {
                            actionLabel("安装描述文件", systemImage: "doc.badge.gearshape", action: .profile)
                        }
                        .disabled(busy).accessibilityIdentifier("installation.local-profile")
                    }
                    Button("导入证书", systemImage: "square.and.arrow.down") { importKind = .certificate; importing = true }
                        .accessibilityIdentifier("installation.certificate")
                    Button { checkCertificate() } label: { actionLabel("检查证书", systemImage: "checkmark.shield", action: .check) }
                        .disabled(busy)
                } header: { Text("本机证书") } footer: {
                    Text("首次使用需创建证书并安装描述文件，然后在「设置 › 通用 › 关于本机 › 证书信任设置」中开启信任。使用代理工具时，请为 ipadn.localtest.me 添加直连（DIRECT）规则。")
                }
            } else {
                Section {
                    TextField("清单服务地址", text: $store.settings.plistServer)
                        .textInputAutocapitalization(.never).autocorrectionDisabled().keyboardType(.URL)
                } header: { Text("代理服务") } footer: {
                    Text("适用于已配置 Surge、Loon 等代理规则的用户。")
                }
            }
            if let helpURL = Self.helpURL {
                Section {
                    Link("安装帮助", destination: helpURL)
                        .accessibilityIdentifier("installation.help")
                }
            }
        }.toolPage().navigationTitle("安装设置").navigationBarTitleDisplayMode(.inline)
            .task {
                let tryImportPairing = store.settings.usesNativeInstallation && NativeInstaller.isSystemVersionSupported && !hasPairingFile
                async let certLoad = refreshCertificate()
                async let pairingImported = Task.detached(priority: .userInitiated) { () -> Result<Bool, Error> in
                    guard tryImportPairing else { return .success(false) }
                    return Result { try NativeInstaller.importPairingFileFromDocuments() }
                }.value
                await certLoad
                if case .success(true) = await pairingImported {
                    hasPairingFile = NativeInstaller.hasPairingFile
                    store.infoMessage = AppText.text("已从 iPadn 文件夹导入配对文件。请在 LocalDevVPN 中连接后点按「检查连接」。")
                }
            }
            .onDisappear { checkTask?.cancel(); checkTask = nil }
            .compatibleOnChange(of: scenePhase) { phase in if phase != .active, working == .profile { working = nil } }
            .sheet(isPresented: $showingPairingGuide) {
                PairingGuideView(pairing: pairing)
                    .presentationDetents([.medium, .large])
                    .interactiveDismissDisabled(pairing.phase.isActive)
            }
            .compatibleOnChange(of: pairing.phase) { phase in
                if phase == .finished {
                    hasPairingFile = NativeInstaller.hasPairingFile
                    store.infoMessage = AppText.text("配对完成。安装前请在 LocalDevVPN 中连接，可以点按「检查连接」确认。")
                }
            }
            // Pairing files come as .plist, .rppairing or no extension at all.
            .fileImporter(isPresented: $importing, allowedContentTypes: importKind == .pairingFile ? [.propertyList, .xml, .data, .item] : [.data], allowsMultipleSelection: false) { result in
                do {
                    guard let url = try result.get().first else { return }
                    let access = url.startAccessingSecurityScopedResource(); defer { if access { url.stopAccessingSecurityScopedResource() } }
                    if importKind == .pairingFile {
                        guard let size = try url.resourceValues(forKeys: [.fileSizeKey]).fileSize, size <= 64 * 1024 else { throw ToolError.message(AppText.text("这不是有效的配对文件。")) }
                        try NativeInstaller.importPairingFile(try Data(contentsOf: url))
                        hasPairingFile = NativeInstaller.hasPairingFile
                        store.infoMessage = AppText.text("配对文件已导入。请在 LocalDevVPN 中连接后点按「检查连接」。")
                        return
                    }
                    guard let size = try url.resourceValues(forKeys: [.fileSizeKey]).fileSize, size <= 2 * 1024 * 1024 else { throw ToolError.message(AppText.text("请选择 .p12 或 .pfx 证书文件")) }
                    deferredCertificateData = try Data(contentsOf: url)
                    scheduleImportPresentation()
                } catch {
                    deferredImportIssue = error.localizedDescription
                    scheduleImportPresentation()
                }
            }
            .compatibleOnChange(of: importing) { isImporting in
                if !isImporting { scheduleImportPresentation() }
            }
            .sheet(isPresented: Binding(get: { certificateData != nil }, set: { if !$0 { certificateData = nil; password = "" } })) {
                NavigationStack {
                    Form {
                        Section { SecureField("证书密码（可留空）", text: $password) } footer: {
                            Text("证书仅保存在这台设备上。")
                        }
                        if let issue { Section { Text(issue).foregroundStyle(.secondary) } }
                    }.navigationTitle("导入证书").navigationBarTitleDisplayMode(.inline)
                        .toolbar {
                            ToolbarItem(placement: .cancellationAction) { Button("取消") { certificateData = nil; password = ""; issue = nil } }
                            ToolbarItem(placement: .confirmationAction) { Button("导入") { saveCertificate() } }
                        }
                }.presentationDetents([.medium, .large])
            }
            .actionConfirmation(isPresented: $removingPairingFile, title: "移除配对文件？", message: "之后使用原生安装需要重新导入。", confirmTitle: "移除", destructive: true) {
                do { try NativeInstaller.removePairingFile(); hasPairingFile = NativeInstaller.hasPairingFile; store.infoMessage = AppText.text("配对文件已移除。") }
                catch { issue = error.localizedDescription }
            }
            .actionConfirmation(isPresented: $replacingCertificate, title: "重新创建证书？", message: "需要重新安装并信任新的描述文件。", confirmTitle: "重新创建", destructive: false) { createLocalCertificate() }
            .alert("安装设置", isPresented: Binding(get: { issue != nil && certificateData == nil }, set: { if !$0 { issue = nil } })) {
                Button("知道了", role: .cancel) { issue = nil }
            } message: { Text(issue ?? "") }
    }
    private func scheduleImportPresentation() {
        guard !importing, (deferredCertificateData != nil || deferredImportIssue != nil) else { return }
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.25) {
            guard !importing else { return }
            if let data = deferredCertificateData {
                deferredCertificateData = nil
                deferredImportIssue = nil
                password = ""
                certificateData = data
            } else if let pendingIssue = deferredImportIssue {
                deferredImportIssue = nil
                issue = pendingIssue
            }
        }
    }
    private func actionLabel(_ title: LocalizedStringKey, systemImage: String, action: Action) -> some View {
        actionLabel(title, systemImage: systemImage, running: working == action)
    }
    private func actionLabel(_ title: LocalizedStringKey, systemImage: String, running: Bool) -> some View {
        HStack {
            Label(title, systemImage: systemImage)
            Spacer()
            if running { ProgressView().transition(.opacity) }
        }
        .animation(.easeOut(duration: 0.15), value: running)
    }
    private func refreshCertificate() async {
        do {
            let loaded = try await Task.detached(priority: .userInitiated) {
                (try InstallationCertificate.load()?.name ?? Self.notImported,
                 try InstallationCertificate.localProfile() != nil)
            }.value
            certificateName = loaded.0
            hasLocalProfile = loaded.1
        }
        catch { issue = error.localizedDescription }
    }
    private func createLocalCertificate() {
        guard !busy else { return }; busy = true; working = .create
        UX.feedback()
        Task {
            defer { busy = false; working = nil }
            do {
                let material = try await Task.detached(priority: .userInitiated) { try LocalInstallationIdentityFactory.create() }.value
                try await Task.detached(priority: .userInitiated) {
                    try InstallationCertificate.save(data: material.pkcs12, password: material.password,
                        localRoot: material.rootCertificate, localIdentifier: material.identifier)
                }.value
                store.installation.stopHosting(); store.settings.localInstallation = true; store.settings.localInstallHost = ManifestBuilder.defaultLocalHost
                ManifestBuilder.invalidateLoopbackHostCache()
                await refreshCertificate()
                store.infoMessage = AppText.text("证书已创建，请安装描述文件。")
            } catch { issue = error.localizedDescription }
        }
    }
    private func installProfile() {
        guard !busy else { return }; busy = true; working = .profile
        UX.feedback()
        Task {
            // The spinner stays until Settings opens with the profile (the app
            // leaves the screen) or a few seconds pass.
            defer { busy = false; Task { try? await Task.sleep(for: .seconds(8)); if working == .profile { working = nil } } }
            do {
                guard let profile = try await Task.detached(priority: .userInitiated, operation: {
                    try InstallationCertificate.localProfile()
                }).value else { throw ToolError.message(AppText.text("请先创建证书")) }
                let url = try await store.installation.profileURL(data: profile)
                openURL(url) { accepted in
                    if accepted { store.infoMessage = AppText.text("请在「设置」中安装描述文件，然后在「通用 › 关于本机 › 证书信任设置」中开启信任。") }
                    else { issue = AppText.text("无法打开描述文件，请稍后重试。"); working = nil }
                }
            } catch { issue = error.localizedDescription; working = nil }
        }
    }
    private func saveCertificate() {
        guard !busy, let data = certificateData else { return }
        let password = self.password
        busy = true
        Task {
            defer { busy = false }
            do {
                try await Task.detached(priority: .userInitiated) {
                    try InstallationCertificate.save(data: data, password: password)
                }.value
                store.installation.stopHosting()
                ManifestBuilder.invalidateLoopbackHostCache()
                certificateData = nil; self.password = ""; issue = nil
                await refreshCertificate(); store.infoMessage = AppText.text("证书已导入。")
            } catch { issue = error.localizedDescription }
        }
    }
    /// Takes a pairing file from iPadn's own folder first; the system file
    /// picker is the fallback for files kept elsewhere.
    private func importPairingFile() {
        guard !busy else { return }
        busy = true
        Task {
            defer { busy = false }
            do {
                let imported = try await Task.detached(priority: .userInitiated) {
                    try NativeInstaller.importPairingFileFromDocuments()
                }.value
                if imported {
                    hasPairingFile = NativeInstaller.hasPairingFile
                    store.infoMessage = AppText.text("已从 iPadn 文件夹导入配对文件。请在 LocalDevVPN 中连接后点按「检查连接」。")
                    return
                }
            } catch {
                issue = error.localizedDescription
                return
            }
            importKind = .pairingFile
            importing = true
        }
    }
    /// Goes through the VPN, the pairing and the tunnel, then asks the system
    /// about iPadn itself: a full rehearsal without installing anything.
    private func checkConnection() {
        guard !busy else { return }; busy = true; working = .connection
        UX.feedback()
        checkTask?.cancel()
        checkTask = Task {
            defer { busy = false; working = nil; checkTask = nil }
            do {
                _ = try await NativeInstaller.lookup(bundleID: Bundle.main.bundleIdentifier ?? "app.local.iPadn")
                store.infoMessage = AppText.text("连接正常，可以使用原生安装。")
            } catch is CancellationError {
            } catch { issue = error.localizedDescription }
        }
    }
    private func checkCertificate() {
        guard !busy else { return }; busy = true; working = .check
        UX.feedback()
        checkTask?.cancel()
        let rawHost = store.settings.localInstallHost
        checkTask = Task {
            defer { busy = false; working = nil; checkTask = nil }
            do {
                let host = try ManifestBuilder.localHost(rawHost)
                guard let certificate = try await Task.detached(priority: .userInitiated, operation: {
                    try InstallationCertificate.load()
                }).value else { throw ToolError.message(AppText.text("请先创建或导入证书")) }
                try await certificate.validateAsync(host: host)
                store.infoMessage = AppText.text("证书有效。")
            } catch is CancellationError {
            } catch { issue = error.localizedDescription }
        }
    }
}

extension OnDevicePairing.Phase {
    var isActive: Bool {
        switch self {
        case .waiting, .connected, .code: return true
        default: return false
        }
    }
}

/// Where on-device pairing is, with the code to type once there is one.
private struct PairingStatusRow: View {
    let phase: OnDevicePairing.Phase
    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            switch phase {
            case .waiting:
                Label("请打开「设置 › 隐私与安全性 › 开发者模式」，点按「与 iPadn 配对」。", systemImage: "gear")
                    .fixedSize(horizontal: false, vertical: true)
            case .connected:
                Label("设备已连接，正在开始配对…", systemImage: "iphone.radiowaves.left.and.right")
                    .fixedSize(horizontal: false, vertical: true)
            case .code(let code):
                Text("在「设置」中输入配对码").font(.subheadline).foregroundStyle(.secondary)
                Text(code).font(.system(size: 40, weight: .bold, design: .rounded)).monospacedDigit().tracking(6)
                    .textSelection(.enabled).frame(maxWidth: .infinity)
                    .accessibilityIdentifier("installation.pairing-code")
            case .finished:
                Label("配对完成", systemImage: "checkmark.circle.fill")
            case .failed(let message):
                Label(message, systemImage: "exclamationmark.triangle")
                    .fixedSize(horizontal: false, vertical: true)
            case .idle:
                EmptyView()
            }
        }
        .font(.subheadline)
        .padding(.vertical, 4)
        .accessibilityIdentifier("installation.pairing-status")
    }
}

/// Shown as soon as pairing starts: what to do next, where pairing is, and
/// the code once the device asks for it.
private struct PairingGuideView: View {
    @ObservedObject var pairing: OnDevicePairing
    @Environment(\.dismiss) private var dismiss
    @Environment(\.openURL) private var openURL
    private var step: Int {
        switch pairing.phase {
        case .waiting: return 1
        case .connected: return 2
        case .code: return 3
        case .finished: return 4
        default: return 0
        }
    }
    var body: some View {
        NavigationStack {
            Form {
                Section {
                    guideRow(1, "打开「设置」前往开发者模式", "点右上角「打开设置」会打开本应用设置页，请点左上角「< 设置」返回首页 ›「隐私与安全性」›「开发者模式」› 选「iPadn」")
                    guideRow(2, "输入锁屏密码并等待连接", "点击 iPadn 后，如有验证弹窗请先输入锁屏密码并稍候建立连接")
                    guideRow(3, "输入 6 位配对码", "配对码会在灵动岛、锁屏或此处显示，填入系统弹窗即可")
                } footer: {
                    Text("看不到「开发者模式」时，需要先在该页面开启并按提示重启设备。配对期间 iPadn 会在后台保持运行，完成后自动停止。")
                }
                // Nothing to show once pairing is cancelled; an empty card would remain.
                if pairing.phase != .idle {
                    Section { PairingStatusRow(phase: pairing.phase) }
                }
            }
            .navigationTitle("在本机配对").navigationBarTitleDisplayMode(.inline)
            .toolbar {
                if pairing.phase.isActive {
                    ToolbarItem(placement: .cancellationAction) {
                        Button("取消配对", role: .destructive) {
                            pairing.cancel()
                            dismiss()
                        }
                        .accessibilityIdentifier("installation.pairing-cancel")
                    }
                }
                ToolbarItem(placement: .confirmationAction) {
                    if pairing.phase.isActive {
                        Button("打开设置") { openSettings() }.accessibilityIdentifier("installation.pairing-open-settings")
                    } else {
                        Button("完成") { dismiss() }
                    }
                }
            }
        }
    }
    // Keys, not Strings: Text(String) is shown verbatim and never translated.
    private func guideRow(_ number: Int, _ title: LocalizedStringKey, _ detail: LocalizedStringKey) -> some View {
        let done = step > number && step != 0
        let current = step == number
        return HStack(alignment: .top, spacing: 12) {
            ZStack {
                Circle()
                    .fill(done || current ? UX.tint : Color(.tertiarySystemFill))
                    .frame(width: 26, height: 26)
                if done {
                    Image(systemName: "checkmark")
                        .font(.caption.weight(.bold))
                        .foregroundStyle(UX.onAccent)
                } else {
                    Text("\(number)")
                        .font(.caption.weight(.bold))
                        .foregroundStyle(current ? UX.onAccent : Color(.label).opacity(0.75))
                }
            }
            VStack(alignment: .leading, spacing: 2) {
                Text(title).font(.body.weight(current ? .semibold : .regular))
                Text(detail).font(.footnote).foregroundStyle(.secondary)
            }
        }
        .padding(.vertical, 2)
        .accessibilityElement(children: .combine)
        .accessibilityIdentifier("installation.pairing-step.\(number)")
    }
    /// The Developer Mode page when the system allows it, else Settings.
    private func openSettings() {
        pairing.notifyHandoffIfWaiting()
        let candidates = ["App-prefs:Privacy&path=DEVELOPER_MODE", "App-prefs:Privacy", UIApplication.openSettingsURLString]
        func attempt(_ index: Int) {
            guard index < candidates.count, let url = URL(string: candidates[index]) else { return }
            openURL(url) { accepted in if !accepted { attempt(index + 1) } }
        }
        attempt(0)
    }
}
