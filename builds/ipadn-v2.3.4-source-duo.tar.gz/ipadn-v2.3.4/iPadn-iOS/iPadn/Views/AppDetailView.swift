import SwiftUI
import UIKit

struct AppDetailView: View {
    @EnvironmentObject private var store: ToolStore
    @EnvironmentObject private var apple: AppleService
    @Environment(\.dynamicTypeSize) private var dynamicTypeSize
    let app: StoreApp
    /// Start the primary download as soon as the page opens (search "获取").
    var autoStart = false
    @State private var autoStarted = false
    @State private var versions: [AppVersion] = []
    @State private var versionsLoading = false
    @State private var manualID = ""
    @State private var versionSearch = ""
    @State private var versionError: String?
    /// Apple's full list, on unless turned off; remembered across apps.
    @AppStorage("storage_officialVersions") private var official = true
    /// Shown above a public list when Apple's could not be used.
    @State private var versionNote: String?
    /// Version number, date and IPA size per version ID, kept outside `@State` so
    /// row loads never re-evaluate the entire 400-row detail screen during scroll.
    @StateObject private var metadataBox = VersionMetadataBox()
    @StateObject private var scrollGate = VersionScrollGate()
    @State private var searchMetadataRevision = 0
    @State private var metadataFailures = 0
    @State private var metadataStopped = false
    /// Long histories start with the newest five versions.
    @State private var showAllVersions = false
    @State private var versionPageLimit = 60
    @State private var dateFrom = Calendar.current.date(byAdding: .year, value: -1, to: Date()) ?? Date()
    @State private var dateThrough = Date()
    @State private var dateFilterExpanded = false
    @StateObject private var dateQuery = VersionDateQuery()
    /// Release notes by version number, from the App Store page's version history.
    @State private var releaseNotes: [String: ReleaseNote] = [:]
    @State private var expandedNotes = Set<String>()
    /// Translations chosen in the system sheet, by version ID.
    @State private var translatedNotes: [String: String] = [:]
    @State private var translatedDescription: String?
    /// The rows on screen belong to the previous region, platform or source
    /// and are replaced as soon as the new list arrives.
    @State private var versionsStale = false
    @State private var showsMacSpinner = false
    /// The latest version-list load; an earlier, cancelled one must not end
    /// its loading state.
    @State private var versionsLoadID = UUID()
    @State private var showLogin = false
    @State private var reauthenticationID: String?
    @State private var showVerification = false
    @State private var retryVersionsAfterVerification = false
    @State private var verifiedForRetry = false
    @State private var showDescription = false
    @State private var collapsedDescriptionHeight: CGFloat = 0
    @State private var fullDescriptionHeight: CGFloat = 0
    @State private var reloadID = 0
    @State private var loadedVersionsKey: String?
    @State private var loadedReloadID = 0
    private var versionsKey: String {
        "\(usesApple)-\(reloadID)-\(store.settings.store.country)-\(store.settings.store.platform.rawValue)-\(apple.activeID ?? "")"
    }
    @State private var macWebsite: URL?
    @State private var macInstallers: [MacInstallerService.Installer] = []
    @State private var macLoading = false
    @State private var enteringMacDownloadURL = false
    @State private var macDownloadURL = ""
    @StateObject private var headerObserver = DetailHeaderScrollObserver()
    @State private var extras: StoreService.ListingExtras?
    /// Until the store listing arrives, the preview keeps its place with
    /// placeholders so the page below doesn't jump.
    @State private var extrasLoaded = LocalResources.isPreview
    @State private var viewing: StoreService.Screenshot?
    @Namespace private var screenshotZoom
    @State private var developerApps: [StoreApp] = []
    /// Listing artwork, else what a download of this app brought along
    /// (delisted apps have no public listing to show).
    private var iconURL: URL? { app.iconURL ?? store.localArtwork(app.id) }
    private var storeURL: URL? { URL(string: "https://apps.apple.com/\(store.settings.store.country.lowercased())/app/id\(app.id)") }
    private var filtered: [AppVersion] {
        let source = dateQuery.range == nil ? versions : dateQuery.matches
        guard !versionSearch.isEmpty else { return source }
        _ = searchMetadataRevision
        return source.filter {
            displayVersion($0).localizedCaseInsensitiveContains(versionSearch) ||
            (versionInfo($0.id)?.bundleShortVersion?.localizedCaseInsensitiveContains(versionSearch) ?? false) ||
            $0.id.contains(versionSearch)
        }
    }
    private func versionInfo(_ id: String) -> VersionMetadata? { metadataBox.metadata[id] ?? dateQuery.values[id] }
    private func displayVersion(_ version: AppVersion) -> String {
        Self.displayVersion(version, info: versionInfo(version.id))
    }

    static func displayVersion(_ version: AppVersion, info: VersionMetadata?) -> String {
        guard let info else {
            return VersionService.sanitizedVersion(version.version, rejectingID: version.id)
        }
        let isLegacyUnseparated = info.bundleShortVersion == nil && (info.metadataSchema ?? 0) < VersionMetadata.currentSchema
        if isLegacyUnseparated && VersionService.versionPreference(version.version, rejectingID: version.id) >= 2 {
            return VersionService.preferredVersion(version.version, over: info.version, rejectingID: version.id)
        }
        return VersionService.preferredVersion(info.version, over: version.version, rejectingID: version.id)
    }

    static func bundleVersionSubtitle(_ version: AppVersion, displayed: String, info: VersionMetadata?) -> String? {
        if let info {
            let rawBundle = info.bundleShortVersion ??
                ((info.bundleShortVersion == nil && (info.metadataSchema ?? 0) < VersionMetadata.currentSchema && info.version != displayed)
                    ? info.version : nil)
            if let rawBundle = rawBundle?.trimmingCharacters(in: .whitespacesAndNewlines),
               !rawBundle.isEmpty, rawBundle != AppVersion.unknown, rawBundle != displayed {
                return AppText.text("包内版本 \(rawBundle)")
            }
        }
        if displayed != AppVersion.unknown && VersionService.versionPreference(displayed, rejectingID: version.id) < 2 {
            return AppText.text("仅包内版本号")
        }
        return nil
    }

    static func isLegacyStaleFallback(_ version: String, versionID: String, schema: Int?, released: Date?,
                                      appVersion: String, in list: [AppVersion], cachedMetadata: [String: VersionMetadata],
                                      rowIndex: Int? = nil) -> Bool {
        let level = schema ?? 0
        if version == AppVersion.unknown, level < VersionMetadata.currentSchema {
            return true
        }
        return level < 2 &&
        VersionService.versionPreference(version, rejectingID: versionID) < 2 &&
        VersionService.isLikelyStaleLatestFallback(
            version, versionID: versionID, appVersion: appVersion,
            versions: list, cachedMetadata: cachedMetadata,
            rowIndex: rowIndex, rowReleased: released
        )
    }

    static func reconciledMetadataEntry(
        incoming: VersionMetadata,
        version: AppVersion,
        rowIndex: Int?,
        currentMeta: VersionMetadata?,
        appVersion: String,
        versions: [AppVersion],
        cachedMetadata: [String: VersionMetadata],
        releaseNotes: [String: ReleaseNote],
        onUpgradeNumber: ((String) -> Void)? = nil
    ) -> (metadata: VersionMetadata, resolvedVersion: String?) {
        let versionID = version.id
        let incomingStale = isLegacyStaleFallback(incoming.version, versionID: versionID, schema: incoming.metadataSchema,
                                                  released: incoming.released, appVersion: appVersion,
                                                  in: versions, cachedMetadata: cachedMetadata, rowIndex: rowIndex)
        let incomingVersion = incomingStale ? AppVersion.unknown : incoming.version
        let rawRowVersion = version.version
        let rowStale = rowIndex != nil && VersionService.versionPreference(rawRowVersion, rejectingID: versionID) < 2 &&
            VersionService.isLikelyStaleLatestFallback(rawRowVersion, versionID: versionID, appVersion: appVersion,
                                                     versions: versions, cachedMetadata: cachedMetadata, rowIndex: rowIndex)
        let rowVersion = rowStale ? AppVersion.unknown : rawRowVersion
        let currentMetaStale = currentMeta.map {
            isLegacyStaleFallback($0.version, versionID: versionID, schema: $0.metadataSchema,
                                  released: $0.released, appVersion: appVersion,
                                  in: versions, cachedMetadata: cachedMetadata, rowIndex: rowIndex)
        } ?? false
        let currentMetaVersion = currentMetaStale ? AppVersion.unknown : (currentMeta?.version ?? AppVersion.unknown)

        let incomingIsLegacyUnseparated = incoming.bundleShortVersion == nil &&
            (incoming.metadataSchema ?? 0) < VersionMetadata.currentSchema
        let incomingPref = VersionService.versionPreference(incomingVersion, rejectingID: versionID)
        let rowPref = VersionService.versionPreference(rowVersion, rejectingID: versionID)
        let incomingMatchesRawBundle = incoming.bundleShortVersion == incomingVersion && incomingVersion != rowVersion

        var resolvedVersion: String
        if rowPref >= 2 && (incomingIsLegacyUnseparated || incomingMatchesRawBundle) && incomingPref >= 2 {
            resolvedVersion = rowVersion
        } else {
            resolvedVersion = VersionService.bestVersion([incomingVersion, currentMetaVersion, rowVersion], rejectingID: versionID)
        }
        let resolvedReleased = incoming.released ?? currentMeta?.released
        var updated = incoming
        if updated.bundleShortVersion == nil {
            updated.bundleShortVersion = currentMeta?.bundleShortVersion ??
                ((incomingIsLegacyUnseparated && rowPref >= 2 && incomingPref >= 2 && incomingVersion != rowVersion) ? incomingVersion : nil)
        }
        if updated.buildVersion == nil {
            updated.buildVersion = currentMeta?.buildVersion
        }
        if resolvedVersion != AppVersion.unknown,
           !releaseNotes.isEmpty,
           VersionService.versionPreference(resolvedVersion, rejectingID: versionID) < 2,
           let upgraded = VersionService.reconcileSingleWithReleaseNotes(
               versionID: versionID, rawVersion: resolvedVersion, released: resolvedReleased,
               versions: versions, metadata: cachedMetadata, notes: Array(releaseNotes.values),
               appVersion: appVersion, rowIndex: rowIndex
           ) {
            resolvedVersion = upgraded
            onUpgradeNumber?(upgraded)
        }
        updated.version = resolvedVersion != AppVersion.unknown ? resolvedVersion : (incomingStale ? AppVersion.unknown : incoming.version)
        var nextRowVersion: String?
        if rowIndex != nil {
            if resolvedVersion != AppVersion.unknown {
                let currentScore = VersionService.versionPreference(rawRowVersion, rejectingID: versionID)
                let resolvedScore = VersionService.versionPreference(resolvedVersion, rejectingID: versionID)
                if (resolvedScore > currentScore || rowVersion == AppVersion.unknown), rawRowVersion != resolvedVersion {
                    nextRowVersion = resolvedVersion
                }
            } else if rowStale, rawRowVersion != AppVersion.unknown {
                nextRowVersion = AppVersion.unknown
            }
        }
        return (updated, nextRowVersion)
    }

    private func reconcileVersionDisplay(_ incoming: VersionMetadata, for versionID: String) {
        let rowIndex = versions.firstIndex(where: { $0.id == versionID })
        let row = rowIndex.map { versions[$0] } ?? AppVersion(id: versionID, version: AppVersion.unknown, source: "")
        let platform = store.settings.store.platform
        let appID = app.id
        let outcome = Self.reconciledMetadataEntry(
            incoming: incoming,
            version: row,
            rowIndex: rowIndex,
            currentMeta: metadataBox.metadata[versionID],
            appVersion: app.version,
            versions: versions,
            cachedMetadata: metadataBox.metadata,
            releaseNotes: releaseNotes
        ) { upgraded in
            Task {
                await store.reconcileVersionNumber(
                    platform: platform, appID: appID, versionID: versionID,
                    version: upgraded, replaceStaleDotless: true
                )
            }
        }
        if metadataBox.metadata[versionID] != outcome.metadata {
            metadataBox.metadata[versionID] = outcome.metadata
        }
        if let rowIndex, let nextRowVersion = outcome.resolvedVersion, versions[rowIndex].version != nextRowVersion {
            versions[rowIndex].version = nextRowVersion
        }
    }

    private func reconcileWithReleaseNotes(persist: Bool = true) {
        guard !versions.isEmpty, !releaseNotes.isEmpty else { return }
        let updates = VersionService.reconcileWithReleaseNotes(
            versions: versions,
            metadata: metadataBox.metadata,
            notes: Array(releaseNotes.values),
            appVersion: app.version
        )
        guard !updates.isEmpty else { return }
        let platform = store.settings.store.platform
        let appID = app.id
        for update in updates {
            if let index = versions.firstIndex(where: { $0.id == update.id }) {
                versions[index].version = update.version
            }
            if var meta = metadataBox.metadata[update.id] {
                meta.version = update.version
                metadataBox.metadata[update.id] = meta
            }
            if persist {
                Task {
                    await store.reconcileVersionNumber(
                        platform: platform, appID: appID, versionID: update.id,
                        version: update.version, replaceStaleDotless: true
                    )
                }
            }
        }
        metadataBox.versionsSnapshot = versions
    }
    /// Lists from Apple carry only version IDs; each row then reads its own
    /// number and date. Other lists use what is already known.
    /// Apple's list needs a signed-in account; otherwise the public list is shown.
    private var usesApple: Bool { official && apple.active != nil }
    private var readsMetadata: Bool { usesApple && versionNote == nil && !metadataStopped }
    var body: some View {
        // A scroll view of drawn cards in a single flat LazyVStack, so screenshots run edge
        // to edge and long version histories recycle without nested lazy-container glitches.
        ScrollView {
            LazyVStack(alignment: .leading, spacing: 0) {
                CardSection {
                    header.onScrolledUnderBar { headerObserver.scrolledAway = $0 }
                        .cardRowInsets(EdgeInsets(top: 12, leading: 20, bottom: 12, trailing: 20))
                    infoStrip.cardRowInsets(EdgeInsets(top: 10, leading: 0, bottom: 10, trailing: 0))
                }
                .padding(.bottom, 24)
                if store.settings.showAppScreenshots,
                   let shots = extrasLoaded ? extras?.screenshots : [],
                   !extrasLoaded || !shots.isEmpty {
                    CardSection(plain: true) {
                        ScreenshotStrip(screenshots: shots, platform: store.settings.store.platform,
                                        zoom: screenshotZoom) { viewing = $0 }
                    } header: { sectionTitle("预览") }
                    .padding(.bottom, 24)
                }
                versionSection
                if store.settings.store.platform == .macOS {
                    macSection.padding(.bottom, 24)
                }
                if !app.description.isEmpty {
                    let displayed = translatedDescription ?? app.description
                    let truncated = fullDescriptionHeight - collapsedDescriptionHeight > 2
                    CardSection {
                        Text(displayed).font(.subheadline)
                            .lineLimit(showDescription ? nil : 4).textSelection(.enabled)
                            .onGeometryChange(for: CGFloat.self) { $0.size.height } action: {
                                collapsedDescriptionHeight = $0
                            }
                            .background {
                                Text(displayed).font(.subheadline)
                                    .fixedSize(horizontal: false, vertical: true)
                                    .hidden()
                                    .accessibilityHidden(true)
                                    .onGeometryChange(for: CGFloat.self) { $0.size.height } action: {
                                        fullDescriptionHeight = $0
                                    }
                            }
                        let translates = TranslateButton.offered(for: app.description, translation: translatedDescription)
                        let showMore = !showDescription && truncated
                        if showMore || translates {
                            HStack {
                                if showMore {
                                    Button("更多") { withAnimation { showDescription = true } }
                                }
                                Spacer()
                                if translates {
                                    TranslateButton(text: app.description, translation: $translatedDescription)
                                        .accessibilityIdentifier("detail.description.translate")
                                }
                            }
                            .font(.subheadline).buttonStyle(.borderless)
                        }
                    } header: { sectionTitle("简介") }
                    .compatibleOnChange(of: translatedDescription) { value in
                        if value != nil, truncated { withAnimation { showDescription = true } }
                    }
                    .padding(.bottom, 24)
                }
                if store.settings.showAppReviews, !app.isDelisted {
                    ReviewsCard(app: app).padding(.bottom, 24)
                }
                if !app.isDelisted {
                    CardSection {
                        if store.isFavorite(app) { PriceHistorySection(app: app) }
                        else {
                            Text("关注后会记录价格变化，降价或限免时提醒你。").font(.subheadline).foregroundStyle(.secondary)
                        }
                        NavigationLink { RegionPriceView(app: app) } label: {
                            HStack {
                                Label("多地区价格对比", systemImage: "globe")
                                Spacer()
                                Image(systemName: "chevron.forward").font(.footnote.weight(.semibold)).foregroundStyle(.tertiary)
                            }
                            .contentShape(Rectangle())
                        }
                        .buttonStyle(.plain)
                        .accessibilityIdentifier("detail.regionPrices")
                    } header: { sectionTitle("价格") }
                    .padding(.bottom, 24)
                }
                CardSection {
                    if app.isDelisted { LabeledContent("商店状态", value: AppText.text("已下架")) }
                    if !app.displayCategory.isEmpty { LabeledContent("类别", value: app.displayCategory) }
                    if app.size > 0 { LabeledContent("大小", value: app.size.byteLabel) }
                    if !app.minimumOS.isEmpty {
                        LabeledContent("兼容性", value: AppText.text("\(store.settings.store.platform.title) \(app.minimumOS) 或更高版本"))
                    }
                    LabeledContent("价格", value: app.priceLabel)
                    LabeledContent("商店地区", value: store.settings.store.country)
                    if !app.bundleID.isEmpty {
                        LabeledContent("Bundle ID") {
                            Text(app.bundleID).font(.footnote.monospaced()).textSelection(.enabled).multilineTextAlignment(.trailing)
                        }
                    }
                    if let developer = extras?.developer, !developer.isEmpty { LabeledContent("开发者", value: developer) }
                    if store.settings.store.platform != .macOS {
                        if let storeURL {
                            Link(destination: storeURL) { Label("在 App Store 中查看", systemImage: "arrow.up.forward.square") }
                        }
                    }
                } header: { sectionTitle("信息") }
                .padding(.bottom, developerApps.isEmpty ? 0 : 24)
                if !developerApps.isEmpty {
                    CardSection {
                        DeveloperAppsStrip(apps: developerApps)
                            .cardRowInsets(EdgeInsets())
                    } header: { sectionTitle(extras?.developer.isEmpty == false ? "更多来自 \(extras!.developer)" : "同一开发者的其他应用") }
                }
            }
            .labeledContentStyle(CardLabeledContentStyle())
            .padding(.top, 8).padding(.bottom, 24)
        }
        .compatibleScrollPhaseTracking(scrollGate)
        .toolPage()
        .onChange(of: versionSearch) { _ in versionPageLimit = 60 }
        .compatibleOnChange(of: versionsKey) { _ in scrollGate.reset() }
        .onDisappear { scrollGate.reset() }
        .navigationTitle("")
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            // App Store shows the small icon in the bar once the header is gone.
            ToolbarItem(placement: .principal) {
                DetailToolbarPrincipalIcon(observer: headerObserver, url: iconURL)
            }
            ToolbarItem(placement: .compatibleTopBarTrailing) {
                Button {
                    let following = !store.isFavorite(app)
                    store.toggleFavorite(app); UX.feedback()
                    if following { store.infoMessage = AppText.text("已关注，有新版本、降价或下架时会提醒你") }
                } label: {
                    Image(systemName: store.isFavorite(app) ? "bell.fill" : "bell")
                        .compatibleSymbolReplacement()
                        .frame(minWidth: 44, minHeight: 44)
                }
                .accessibilityLabel(store.isFavorite(app) ? AppText.text("取消关注") : AppText.text("关注应用"))
            }
        }
        .alert("下载 Mac 安装包", isPresented: $enteringMacDownloadURL) {
            TextField("https://example.com/App.dmg", text: $macDownloadURL)
                .textInputAutocapitalization(.never)
                .autocorrectionDisabled()
            Button("加入下载") {
                let value = macDownloadURL.trimmingCharacters(in: .whitespacesAndNewlines)
                guard let url = URL(string: value), MacInstallerService.directPackage(url) else {
                    store.errorMessage = AppText.text("请输入有效的 HTTPS 下载链接，文件需要是 DMG、PKG 或 ZIP。")
                    return
                }
                enqueueMacInstaller(MacInstallerService.Installer(url: url))
                macDownloadURL = ""
            }
            Button("取消", role: .cancel) { }
        } message: {
            Text("输入 DMG、PKG 或 ZIP 安装包的下载链接。")
        }
        .navigationDestination(isPresented: $showLogin) {
            LoginView(initialAccountID: reauthenticationID, onSignedIn: {
                reauthenticationID = nil
            })
        }
        .sheet(isPresented: $showVerification, onDismiss: {
            guard verifiedForRetry else {
                retryVersionsAfterVerification = false
                return
            }
            verifiedForRetry = false
            if retryVersionsAfterVerification {
                retryVersionsAfterVerification = false
                reloadID += 1
            }
        }) {
            if let accountID = apple.activeID {
                ExistingAccountVerificationView(accountID: accountID, onVerified: {
                    verifiedForRetry = true
                })
                .environmentObject(store)
                .environmentObject(apple)
            }
        }
        .onDisappear { dateQuery.cancel() }
        .task {
            // Getting the app needs the signing runtime; load it while the page is read.
            if apple.active != nil, store.settings.useSignerCache { store.signer.prewarm() }
            guard autoStart, !autoStarted else { return }
            autoStarted = true
            if apple.active == nil { showLogin = true }
            else {
                store.triggerAppStoreAction(
                    for: app,
                    versionID: app.externalVersionID,
                    marketingVersion: app.version,
                    onEnqueued: reloadIfLicenseWasMissing
                )
            }
        }
        .task(id: versionsKey) {
            // Coming back to the page (e.g. from the Downloads tab) keeps the
            // loaded list; only a new key or 刷新 fetches again.
            guard versionsKey != loadedVersionsKey else { return }
            dateQuery.clear()
            metadataBox.clear()
            metadataFailures = 0; metadataStopped = false
            versionPageLimit = 60
            let forced = reloadID != loadedReloadID
            // A different region, platform or account lists different versions.
            // The old rows stay (dimmed) until the new list replaces them, so the
            // page doesn't collapse and grow again.
            if !forced { versionsStale = !versions.isEmpty }
            let loaded = await fetchVersions(force: forced)
            if loaded { loadedVersionsKey = versionsKey; loadedReloadID = reloadID }
            else if versionsStale, !Task.isCancelled { versions = [] }
            if !Task.isCancelled { versionsStale = false }
        }
        .task(id: "\(app.id)-\(store.settings.store.platform.rawValue)-\(store.settings.store.country)") {
            await loadMacInstallers()
        }
        .task(id: "notes-\(app.id)-\(store.settings.store.country)-\(reloadID)") {
            guard !LocalResources.isPreview, !app.isDelisted else { return }
            // The search region's page, else the account's, then CN fallback when overseas storefronts geo-redirect.
            var countries = [store.settings.store.country.uppercased()]
            if !countries.contains(store.watchCountry) { countries.append(store.watchCountry) }
            if !countries.contains("CN") { countries.append("CN") }
            let notes = await ReleaseNotesService.notes(appID: app.id, countries: countries, force: reloadID > 0)
            guard !Task.isCancelled else { return }
            try? await scrollGate.waitUntilSettled()
            guard !Task.isCancelled else { return }
            releaseNotes = notes
            metadataBox.releaseNotesSnapshot = notes
            reconcileWithReleaseNotes()
        }
        .task(id: "extras-\(app.id)-\(store.settings.store.platform.rawValue)-\(store.settings.store.country)") {
            // Demo data stays offline.
            guard !LocalResources.isPreview else { return }
            let found = try? await StoreService.listingExtras(id: app.id, country: store.settings.store.country,
                                                            platform: store.settings.store.platform)
            guard !Task.isCancelled else { return }
            extras = found; extrasLoaded = true
            guard let developerID = found?.developerID else { developerApps = []; return }
            let apps = (try? await StoreService.developerApps(developerID, excluding: app.id, country: store.settings.store.country,
                                                             platform: store.settings.store.platform)) ?? []
            guard !Task.isCancelled else { return }
            developerApps = apps
        }
        .compatibleOnChange(of: store.settings.showAppScreenshots) { on in
            if !on { viewing = nil }
        }
        .fullScreenCover(item: $viewing) { shot in
            ScreenshotViewer(screenshots: extras?.screenshots ?? [shot], selection: shot)
                .zoomTransition(shot.id, in: screenshotZoom)
        }
    }
    /// Versions shown before “Show all”.
    static let collapsedVersions = 5
    static let releaseDateFormat = Date.FormatStyle.dateTime.year().month().day()
    static let versionRowInsets = EdgeInsets(top: 11, leading: 20, bottom: 11, trailing: 20)
    private func sectionTitle(_ text: LocalizedStringKey) -> some View {
        Text(text).font(.title3.weight(.bold)).foregroundStyle(.primary).textCase(nil)
    }

    /// App Store product header: big icon, name, subtitle and the primary capsule.
    private var header: some View {
        HStack(alignment: .top, spacing: 16) {
            AppIcon(url: iconURL, size: 112)
            VStack(alignment: .leading, spacing: 4) {
                Text(app.name.isEmpty ? app.bundleID : app.name).font(.title3.weight(.bold))
                    .lineLimit(2).minimumScaleFactor(0.85).fixedSize(horizontal: false, vertical: true)
                if app.isDelisted {
                    TagBadge(text: "已下架", tint: .orange)
                } else if !app.displayCategory.isEmpty {
                    Text(app.displayCategory).font(.subheadline).foregroundStyle(.secondary).lineLimit(1)
                }
                HStack(alignment: .firstTextBaseline, spacing: 8) {
                    Text(app.version.isEmpty ? "版本待查询" : "v\(app.version)")
                        .font(.footnote.monospacedDigit()).foregroundStyle(.secondary)
                        .layoutPriority(1)
                        .accessibilityIdentifier("app.version")
                    Spacer(minLength: 4)
                    Button { copy(app.id) } label: {
                        HStack(spacing: 4) {
                            Text("ID \(app.id)").monospacedDigit().lineLimit(1)
                            Image(systemName: "doc.on.doc")
                        }.font(.caption).foregroundStyle(.secondary).contentShape(Rectangle())
                    }
                    .buttonStyle(.borderless)
                    .accessibilityLabel("App ID \(app.id)，点按复制")
                    .accessibilityIdentifier("app.copy-id")
                }
                Spacer(minLength: 10)
                HStack(spacing: 12) {
                    primaryButton
                    Spacer(minLength: 0)
                    if let storeURL {
                        ShareLink(item: storeURL) { Image(systemName: "square.and.arrow.up").font(.title3) }
                            .buttonStyle(.borderless).accessibilityLabel("分享商店链接")
                    }
                }
                if let account = apple.active, store.settings.store.platform.supportsIPA || store.settings.store.platform == .macOS {
                    Text("使用 \(account.id)").font(.caption2).foregroundStyle(.tertiary).lineLimit(1)
                }
            }
            .frame(maxWidth: .infinity, minHeight: 112, alignment: .leading)
        }
    }

    @ViewBuilder private var primaryButton: some View {
        if apple.active == nil {
            RowCapsule(title: "登录", filled: true) { showLogin = true }
        } else {
            StoreDownloadActionButton(
                app: app,
                versionID: app.externalVersionID,
                marketingVersion: app.version,
                idleTitle: store.settings.store.platform.supportsIPA ? (app.isFree ? "获取" : "下载") : "获取 PKG",
                filled: true,
                alignment: .center,
                onEnqueued: reloadIfLicenseWasMissing
            )
            .accessibilityIdentifier(store.settings.store.platform.supportsIPA ? "detail.get" : "mac.official-pkg")
        }
    }

    /// Info strip under the header. At most four equal cells so it always
    /// fits on one line; everything else is in the 信息 section below.
    private var infoStrip: some View {
        let items = Array(stripItems.prefix(4))
        return HStack(spacing: 0) {
            ForEach(items.indices, id: \.self) { index in
                items[index]
                if index < items.count - 1 { Divider().frame(height: 40) }
            }
        }
        .padding(.horizontal, 8)
    }

    private var stripItems: [InfoStripItem] {
        let platform = store.settings.store.platform
        var items: [InfoStripItem] = []
        if app.rating > 0 {
            items.append(InfoStripItem(caption: "评分", value: String(format: "%.1f", app.rating),
                                       detail: String(repeating: "★", count: max(0, min(5, Int(app.rating.rounded()))))))
        }
        if app.size > 0 {
            let parts = app.size.byteLabel.components(separatedBy: " ")
            items.append(InfoStripItem(caption: "大小", value: parts.first ?? app.size.byteLabel, detail: parts.count > 1 ? parts.last : nil))
        }
        if !app.minimumOS.isEmpty {
            items.append(InfoStripItem(caption: "兼容性", value: app.minimumOS + "+", detail: platform.title))
        } else {
            items.append(InfoStripItem(caption: "平台", value: platform.title, symbol: platform.symbol))
        }
        if app.isDelisted {
            items.append(InfoStripItem(caption: "状态", value: AppText.text("已下架"), symbol: "archivebox"))
        } else if !app.displayCategory.isEmpty {
            items.append(InfoStripItem(caption: "类别", value: app.displayCategory, symbol: "square.grid.2x2"))
        }
        items.append(InfoStripItem(caption: "地区", value: store.settings.store.country, detail: AppText.text("商店")))
        return items
    }

    @ViewBuilder
    private func versionCardRow<Content: View>(first: Bool = false, last: Bool = false, @ViewBuilder content: () -> Content) -> some View {
        let cornerRadius = CardSection<EmptyView, EmptyView>.cornerRadius
        VStack(spacing: 0) {
            if !first { Divider().padding(.leading, 20) }
            content()
                .padding(Self.versionRowInsets)
                .frame(maxWidth: .infinity, minHeight: 44, alignment: .leading)
        }
        .background(
            Color(.secondarySystemGroupedBackground),
            in: CompatibleCardShape(top: first ? cornerRadius : 0, bottom: last ? cornerRadius : 0)
        )
        .padding(.horizontal, CardSection<EmptyView, EmptyView>.pageMargin)
    }

    @ViewBuilder private var versionSection: some View {
        let matches = filtered
        // Searching and date queries are paged too, never an eager full history.
        let expanded = showAllVersions || !versionSearch.isEmpty || dateQuery.range != nil
        let limit = expanded ? versionPageLimit : Self.collapsedVersions
        let showsEmptyState = !versions.isEmpty && matches.isEmpty && !dateQuery.running
        let showsLoadMore = expanded && matches.count > limit
        let showsExpandToggle = versionSearch.isEmpty && dateQuery.range == nil && matches.count > Self.collapsedVersions
        let showsNoHistory = versions.isEmpty && !versionsLoading && versionError == nil
        let platform = store.settings.store.platform
        let isVisualPreview = store.isVisualPreview
        let appID = app.id
        let showIcons = store.settings.showHistoryIcons
        let allowMetadata = readsMetadata

        HStack(alignment: .firstTextBaseline) {
            sectionTitle("版本历史")
            Spacer()
            RefreshButton(busy: versionsLoading) { reloadID += 1 }
                .accessibilityIdentifier("detail.versions.refresh")
        }
        .padding(.horizontal, CardSection<EmptyView, EmptyView>.pageMargin + 20)
        .padding(.bottom, 10)

        versionCardRow(first: true) {
            Toggle("从 Apple 获取完整版本列表", isOn: $official).font(.subheadline)
                .disabled(apple.active == nil)
        }
        if let versionError {
            versionCardRow { InlineIssue(message: versionError) { reloadID += 1 } }
        }
        if let versionNote {
            versionCardRow {
                Label(versionNote, systemImage: "info.circle").font(.footnote).foregroundStyle(.secondary)
            }
        }
        if versions.count > 6 {
            versionCardRow { SearchInput(text: $versionSearch, placeholder: "筛选版本号或版本 ID") }
        }
        versionCardRow { dateRangeControls }
        if versions.isEmpty && versionsLoading {
            // Placeholders where the rows will be, instead of a spinner row
            // that appears and disappears.
            ForEach(0..<3, id: \.self) { _ in
                versionCardRow { VersionRowSkeleton() }
            }
        }
        ForEach(matches.prefix(limit)) { version in
            let effectiveInfo = metadataBox.metadata[version.id] ?? dateQuery.values[version.id]
            let initialName = Self.displayVersion(version, info: effectiveInfo)
            let note = initialName != AppVersion.unknown ? releaseNotes[initialName] : nil
            versionCardRow {
                VersionRowView(
                    store: store,
                    app: app,
                    version: version,
                    initialMetadata: effectiveInfo,
                    resolvedNote: note,
                    cacheKey: VersionMetadataStore.key(platform: platform, appID: appID, versionID: version.id),
                    isVisualPreview: isVisualPreview,
                    isExpanded: expandedNotes.contains(version.id),
                    translatedNote: translatedNotes[version.id],
                    showHistoryIcons: showIcons,
                    supportsIPA: platform.supportsIPA,
                    readsMetadata: allowMetadata,
                    versionsKey: versionsKey,
                    versionsStale: versionsStale,
                    scrollGate: scrollGate,
                    metadataBox: metadataBox,
                    onToggleNote: {
                        withAnimation(.easeInOut(duration: 0.2)) {
                            if expandedNotes.contains(version.id) { expandedNotes.remove(version.id) }
                            else { expandedNotes.insert(version.id) }
                        }
                    },
                    onTranslateNote: { translatedNotes[version.id] = $0 },
                    onCopy: { copy($0) },
                    onEnqueued: reloadIfLicenseWasMissing,
                    onVersionResolved: {
                        if !versionSearch.isEmpty { searchMetadataRevision &+= 1 }
                    },
                    onAuthFailure: { metadataStopped = true },
                    onFailure: {
                        metadataFailures += 1
                        if metadataFailures >= 5 { metadataStopped = true }
                    },
                    onSuccess: { metadataFailures = 0 }
                )
                .opacity(versionsStale ? 0.4 : 1)
                .disabled(versionsStale)
            }
        }
        if showsEmptyState {
            versionCardRow {
                Text(dateQuery.range != nil && dateQuery.incomplete ? LocalizedStringKey("尚未找到匹配版本，结果不完整。") : LocalizedStringKey("没有匹配的版本。"))
                    .font(.subheadline).foregroundStyle(.secondary)
            }
        }
        if showsLoadMore {
            versionCardRow {
                Button("加载更多版本") { versionPageLimit += 60 }
                    .accessibilityIdentifier("detail.versions.more")
                    .task(id: limit) {
                        // Lazy footer prefetches the next batch once scrolling settles.
                        do {
                            try await Task.sleep(nanoseconds: 80_000_000)
                            try await scrollGate.waitUntilSettled()
                        } catch { return }
                        if !Task.isCancelled && versionPageLimit == limit { versionPageLimit += 60 }
                    }
            }
        }
        if showsExpandToggle {
            versionCardRow {
                Button {
                    withAnimation(.compatibleSnappy) { showAllVersions.toggle(); versionPageLimit = 60 }
                } label: {
                    HStack {
                        Text(showAllVersions ? LocalizedStringKey("收起") : LocalizedStringKey("展开版本列表（\(matches.count) 个版本）"))
                        Spacer()
                        Image(systemName: "chevron.down").rotationEffect(.degrees(showAllVersions ? 180 : 0))
                    }
                    .font(.subheadline.weight(.medium))
                    .contentShape(Rectangle())
                }
                .accessibilityIdentifier("detail.versions.toggle")
            }
        }
        if showsNoHistory {
            versionCardRow { Text("暂无历史版本").font(.subheadline).foregroundStyle(.secondary) }
        }
        versionCardRow(last: true) {
            DisclosureGroup("手动指定版本 ID") {
                HStack {
                    TextField("内部版本 ID", text: $manualID).keyboardType(.numberPad)
                    let manual = manualID.trimmingCharacters(in: .whitespacesAndNewlines)
                    StoreDownloadActionButton(
                        app: app,
                        versionID: manual,
                        idleTitle: "下载",
                        filled: false,
                        enabled: !manual.isEmpty,
                        alignment: .center,
                        onEnqueued: reloadIfLicenseWasMissing
                    )
                }
            }
        }
        .padding(.bottom, 24)
    }

    /// One compact block: the filter, its action row and the live status stay
    /// visually grouped instead of becoming several separate card rows.
    @ViewBuilder private var dateRangeControls: some View {
        VStack(alignment: .leading, spacing: 12) {
            DisclosureGroup(isExpanded: $dateFilterExpanded) {
                VStack(alignment: .leading, spacing: 10) {
                    VStack(spacing: 0) {
                        dateField("开始日期", selection: $dateFrom, id: "detail.versions.date.from")
                        Divider()
                        dateField("结束日期", selection: $dateThrough, id: "detail.versions.date.through")
                    }
                    dateActionRow
                    Text("首次查询需逐个读取版本日期，可取消；只为显示的结果加载图标。包内日期可能与商店发布日期不同。")
                        .font(.caption).foregroundStyle(.secondary)
                        .fixedSize(horizontal: false, vertical: true)
                }
                .padding(.top, 10)
            } label: {
                Text("按日期范围筛选").font(.subheadline.weight(.medium))
            }
            if let range = dateQuery.range { dateStatus(range) }
        }
    }

    private var canStartDateQuery: Bool {
        !versionsLoading && !versionsStale && !versions.isEmpty &&
            VersionDateRange(from: dateFrom, through: dateThrough) != nil
    }

    /// Label on the left, the system's compact date field on the right, so both
    /// fields line up whatever the language or text size.
    private func dateField(_ title: LocalizedStringKey, selection: Binding<Date>, id: String) -> some View {
        let picker = DatePicker("", selection: selection, displayedComponents: .date)
            .labelsHidden()
            .datePickerStyle(.compact)
            .accessibilityIdentifier(id)
        return Group {
            if dynamicTypeSize.isAccessibilitySize {
                // A wide date beside a large label would otherwise be clipped.
                VStack(alignment: .leading, spacing: 6) {
                    Text(title).font(.subheadline)
                    picker
                }
            } else {
                HStack(spacing: 12) {
                    Text(title).font(.subheadline)
                    Spacer(minLength: 8)
                    picker
                }
            }
        }
        .frame(minHeight: 38)
    }

    private var dateActionRow: some View {
        let search = Button { startDateQuery() } label: {
            Text("查询")
                .font(.subheadline.weight(.semibold))
                .foregroundStyle(UX.onAccent)
                .padding(.horizontal, 18)
                .frame(minHeight: 32)
                .background(UX.tint, in: Capsule())
        }
        .buttonStyle(.plain)
        .disabled(!canStartDateQuery)
        .opacity(canStartDateQuery ? 1 : 0.4)
        .accessibilityIdentifier("detail.versions.date.search")
        return Group {
            if dynamicTypeSize.isAccessibilitySize {
                VStack(alignment: .leading, spacing: 10) {
                    search
                    dateSecondaryActions
                }
            } else {
                HStack(spacing: 16) {
                    search
                    Spacer(minLength: 0)
                    dateSecondaryActions
                }
            }
        }
    }

    @ViewBuilder private var dateSecondaryActions: some View {
        if dateQuery.running {
            Button("取消查询") { dateQuery.cancel() }
                .font(.subheadline)
                .accessibilityIdentifier("detail.versions.date.cancel")
        }
        if dateQuery.range != nil {
            Button("清除筛选") { dateQuery.clear(); versionPageLimit = 60 }
                .font(.subheadline)
                .accessibilityIdentifier("detail.versions.date.clear")
        }
    }

    /// Range, progress and any caveat share one panel so an incomplete scan
    /// reads as one state instead of a stack of unrelated lines.
    private func dateStatus(_ range: VersionDateRange) -> some View {
        VStack(alignment: .leading, spacing: 6) {
            HStack(alignment: .firstTextBaseline, spacing: 8) {
                Text("查询范围：\(range.start.formatted(date: .abbreviated, time: .omitted)) — \(range.endExclusive.addingTimeInterval(-1).formatted(date: .abbreviated, time: .omitted))")
                    .font(.caption).foregroundStyle(.secondary)
                    .fixedSize(horizontal: false, vertical: true)
                Spacer(minLength: 0)
                if dateQuery.running { ProgressView().controlSize(.small) }
            }
            Text("已检查 \(dateQuery.checked) / \(dateQuery.total) 个版本，找到 \(dateQuery.matches.count) 个")
                .font(.footnote.monospacedDigit().weight(.medium))
                .accessibilityIdentifier("detail.versions.date.progress")
            if dateQuery.incomplete {
                Label("结果尚不完整：\(dateQuery.unknown) 个日期未知，\(dateQuery.total - dateQuery.checked) 个尚未检查。",
                      systemImage: "exclamationmark.circle")
                    .font(.caption).foregroundStyle(.secondary)
                    .fixedSize(horizontal: false, vertical: true)
            }
            if dateQuery.stoppedForAccount {
                Label("账号验证失效，查询已停止。请重新登录后重试。",
                      systemImage: "person.crop.circle.badge.exclamationmark")
                    .font(.caption).foregroundStyle(.secondary)
                    .fixedSize(horizontal: false, vertical: true)
            }
        }
        .padding(.horizontal, 12).padding(.vertical, 10)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(Color(.tertiarySystemFill).opacity(0.55),
                    in: RoundedRectangle(cornerRadius: 12, style: .continuous))
    }

    private func startDateQuery() {
        guard let range = VersionDateRange(from: dateFrom, through: dateThrough) else { return }
        versionPageLimit = 60
        var cached = dateQuery.values.merging(metadataBox.metadata) { _, row in row }
        for version in versions {
            if !readsMetadata, cached[version.id] == nil {
                cached[version.id] = VersionMetadata(version: version.version, released: nil)
            } else if var existing = cached[version.id] {
                let better = VersionService.preferredVersion(version.version, over: existing.version, rejectingID: version.id)
                if better != existing.version {
                    existing.version = better
                    cached[version.id] = existing
                }
            }
        }
        dateQuery.start(versions: versions, range: range, cached: cached,
                        notes: releaseNotes.compactMapValues(\.date)) { version in
            guard readsMetadata else { throw RemoteZip.Failure.notFound }
            return try await store.versionMetadata(app: app, versionID: version.id,
                                                   includingIcon: false,
                                                   knownVersion: version.version,
                                                   knownVersions: versions)
        }
    }

    @ViewBuilder private var macSection: some View {
        CardSection {
            Text(MacPackageDecryptor.isAvailable
                 ? "下载完成后可导出到 Mac 安装。"
                 : "仅支持下载未加密的 Mac 安装包。")
                .font(.footnote).foregroundStyle(.secondary)
            ForEach(macInstallers) { installer in
                HStack(spacing: 12) {
                    Image(systemName: "shippingbox").foregroundStyle(.secondary).frame(width: 28)
                    VStack(alignment: .leading, spacing: 2) {
                        Text(installer.title).font(.subheadline.weight(.medium)).lineLimit(2)
                        Text("来自开发者网站 · \(installer.format.uppercased())").font(.caption).foregroundStyle(.secondary)
                    }
                    Spacer(minLength: 8)
                    RowCapsule(title: "下载") { enqueueMacInstaller(installer) }
                        .accessibilityIdentifier("mac.download." + installer.format)
                }
            }
            Button("通过链接下载", systemImage: "link") { enteringMacDownloadURL = true }
                .accessibilityIdentifier("mac.manual-download")
            if let website = macWebsite {
                Link(destination: website) { Label("开发者网站", systemImage: "safari") }
            }
        } header: {
            // Looking for the developer's installers shows here rather than
            // as a row that comes and goes.
            HStack(alignment: .firstTextBaseline) {
                sectionTitle("Mac 安装包")
                Spacer()
                if showsMacSpinner { ProgressView().controlSize(.small).transition(.opacity) }
            }
            .revealAfterDelay(macLoading, into: $showsMacSpinner)
        }
    }

    private func copy(_ text: String) { UIPasteboard.general.string = text; store.infoMessage = AppText.text("已复制到剪贴板"); UX.feedback() }
    /// Returns whether the list was loaded. The previous list stays visible
    /// until the new one arrives.
    @discardableResult
    private func fetchVersions(force: Bool) async -> Bool {
        // An earlier error stays until this attempt settles, instead of
        // disappearing and coming back.
        let loadID = UUID(); versionsLoadID = loadID
        versionsLoading = true
        defer { if versionsLoadID == loadID { versionsLoading = false } }
        do {
            var result: [AppVersion]
            do {
                result = try await store.loadVersions(for: app, force: force, official: usesApple)
                versionNote = nil
            } catch is AppleLicenseError {
                // Not got by this account yet: show what is public, and say why.
                result = try await store.loadVersions(for: app, force: force, official: false)
                versionNote = AppText.text("此账号还没有获取这个应用，下面是公开的版本资料。获取后可查看完整列表。")
            } catch {
                if usesApple, let publicVersions = try? await store.loadVersions(for: app, force: force, official: false), !publicVersions.isEmpty {
                    result = publicVersions
                    versionNote = AppText.text("Apple 版本服务暂时未返回，已为你显示公开版本列表。可稍后点击刷新重试。")
                } else {
                    throw error
                }
            }
            try Task.checkCancellation()
            var sanitizedResult = result
            if versionsStale { showAllVersions = false }
            if force { metadataStopped = false; metadataFailures = 0 }
            let cached = await store.cachedVersionMetadata(app: app, versionIDs: sanitizedResult.map(\.id))
            try Task.checkCancellation()
            let platform = store.settings.store.platform
            let currentApp = self.app
            for index in sanitizedResult.indices {
                let rowID = sanitizedResult[index].id
                let rawVersion = sanitizedResult[index].version
                if VersionService.versionPreference(rawVersion, rejectingID: rowID) < 2,
                   VersionService.isLikelyStaleLatestFallback(
                       rawVersion, versionID: rowID, appVersion: currentApp.version,
                       versions: sanitizedResult, cachedMetadata: cached, rowIndex: index
                   ) {
                    sanitizedResult[index].version = AppVersion.unknown
                    Task {
                        await store.reconcileVersionNumber(
                            platform: platform, appID: currentApp.id, versionID: rowID,
                            version: AppVersion.unknown, replaceStaleDotless: true
                        )
                    }
                }
            }
            versions = sanitizedResult; versionError = nil
            metadataBox.replaceAll([:])
            metadataBox.versionsSnapshot = sanitizedResult
            metadataBox.releaseNotesSnapshot = releaseNotes
            let rowVersions = Dictionary(sanitizedResult.map { ($0.id, $0.version) }, uniquingKeysWith: { first, _ in first })
            let rowIndices = Dictionary(sanitizedResult.enumerated().map { ($1.id, $0) }, uniquingKeysWith: { first, _ in first })
            for (id, entry) in cached {
                let rowIndex = rowIndices[id]
                if Self.isLegacyStaleFallback(entry.version, versionID: id, schema: entry.metadataSchema,
                                              released: entry.released, appVersion: currentApp.version,
                                              in: sanitizedResult, cachedMetadata: cached,
                                              rowIndex: rowIndex) {
                    continue
                }
                reconcileVersionDisplay(entry, for: id)
                if let rowVersion = rowVersions[id],
                   VersionService.versionPreference(rowVersion, rejectingID: id) >
                   VersionService.versionPreference(entry.version, rejectingID: id) {
                    Task { await store.reconcileVersionNumber(platform: platform, appID: currentApp.id, versionID: id, version: rowVersion) }
                }
            }
            reconcileWithReleaseNotes()
            metadataBox.versionsSnapshot = versions
            return true
        } catch is CancellationError { }
        catch AppleAuthError.reauthenticationRequired {
            if !Task.isCancelled {
                reauthenticationID = apple.activeID
                retryVersionsAfterVerification = false
                showLogin = true
            }
        }
        catch AppleLoginError.verificationRequired {
            if !Task.isCancelled {
                retryVersionsAfterVerification = true
                showVerification = true
            }
        }
        catch {
            if !Task.isCancelled {
                let message = error.localizedDescription
                if error is VersionListUnavailableError || error is AppleLicenseError {
                    versionError = message
                } else if let tool = error as? ToolError, case .message(let text) = tool {
                    versionError = text
                } else {
                    versionError = AppErrorMessage.forSearch(error)
                }
            }
        }
        return false
    }
    /// A download claims a free app's license, so a list that failed for
    /// lack of one can load now.
    private func reloadIfLicenseWasMissing() {
        if versionNote != nil || versionError == AppleLicenseError.notOwned.errorDescription { reloadID += 1 }
    }

    private func enqueueMacInstaller(_ installer: MacInstallerService.Installer) {
        do {
            try store.downloads.enqueueMacInstaller(installer.url, for: app)
            store.selectTab(.downloads)
        } catch { store.errorMessage = error.localizedDescription }
    }

    private func loadMacInstallers() async {
        guard store.settings.store.platform == .macOS else { return }
        macLoading = true
        macInstallers = []
        defer { macLoading = false }
        var website = app.developerURL
        if website == nil, app.id.allSatisfy({ $0.isNumber }) {
            let query = SearchQuery.appID(app.id, versionID: nil)
            if let matches = try? await StoreService.search(query, store: store.settings.store, limit: 1) {
                website = matches.first(where: { $0.id == app.id })?.developerURL
            }
        }
        guard !Task.isCancelled else { return }
        macWebsite = website
        if let website, let installers = try? await MacInstallerService.find(on: website),
           !Task.isCancelled {
            macInstallers = installers
        }
    }
}

/// App Store style preview strip: screenshots side by side on the page
/// background, snapping to the leading margin, with the next one peeking in.
private struct ScreenshotStrip: View {
    /// Empty while the listing is still loading: placeholders only.
    let screenshots: [StoreService.Screenshot]
    let platform: AppPlatform
    let zoom: Namespace.ID
    var open: (StoreService.Screenshot) -> Void
    /// Loaded images. The size in a screenshot link is only the box Apple
    /// fits the image into, so a landscape game shot can arrive under a
    /// portrait-looking link: once all are in, lay each one out by the real image.
    @State private var images: [URL: UIImage] = [:]
    @State private var failed = Set<URL>()
    @State private var legacyWidth: CGFloat = 1
    private var ready: Bool { !screenshots.isEmpty && screenshots.allSatisfy { images[$0.url] != nil || failed.contains($0.url) } }
    private func aspect(_ shot: StoreService.Screenshot) -> Double {
        let fallback = (shot.aspect.isFinite && shot.aspect > 0) ? max(0.1, shot.aspect) : 0.5625
        guard ready, let image = images[shot.url], image.size.width > 0, image.size.height > 0 else { return fallback }
        let ratio = Double(image.size.width / image.size.height)
        return (ratio.isFinite && ratio > 0) ? max(0.1, ratio) : fallback
    }
    var body: some View {
        let margin = CardSection<EmptyView, EmptyView>.pageMargin
        let placeholders = screenshots.isEmpty
        // iPhone shots are portrait; iPad, Apple TV and Mac shots are mostly wide.
        let placeholderAspect = platform == .iOS ? 0.462 : platform == .iPadOS ? 1.33 : 1.6
        VStack(alignment: .leading, spacing: 10) {
            // Full page width: screenshots scroll from screen edge to screen
            // edge and rest lined up with the cards.
            ScrollView(.horizontal, showsIndicators: false) {
                LazyHStack(spacing: 10) {
                    if placeholders {
                        ForEach(0..<3, id: \.self) { _ in
                            screenshotWidth(of: ScreenshotTile(image: nil, failed: false, cornerRadius: placeholderAspect < 1 ? 22 : 14)
                                .aspectRatio(placeholderAspect, contentMode: .fit), aspect: placeholderAspect, margin: margin)
                        }
                    }
                    ForEach(screenshots) { shot in
                        let ratio = aspect(shot)
                        let portrait = ratio < 1
                        Button { open(shot) } label: {
                            screenshotWidth(of: ScreenshotTile(image: ready ? images[shot.url] : nil, failed: failed.contains(shot.url),
                                           cornerRadius: portrait ? 22 : 14)
                                .aspectRatio(ratio, contentMode: .fit), aspect: ratio, margin: margin)
                        }
                        .buttonStyle(.plain)
                        .zoomSource(shot.id, in: zoom)
                        .accessibilityLabel("截图")
                    }
                }
                .compatibleScrollTargetLayout()
                .legacyHorizontalPadding(margin)
            }
            .compatibleHorizontalScrollMargins(margin)
            .compatibleViewAlignedScrolling()
            .scrollDisabled(placeholders)
            HStack(spacing: 8) {
                DeviceGlyph(platform: platform)
                Text(platform == .iOS ? "iPhone" : platform == .tvOS ? "Apple TV" : platform.title)
            }
            .font(.footnote).foregroundStyle(.secondary)
            .padding(.horizontal, margin)
        }
        .measureLegacyWidth($legacyWidth)
        .task(id: screenshots.map(\.url)) { await load() }
        .onDisappear { images.removeAll() }
        .accessibilityIdentifier("detail.screenshots")
    }

    @ViewBuilder private func screenshotWidth(of content: some View, aspect: Double, margin: CGFloat) -> some View {
        if #available(iOS 17, *) {
            content.containerRelativeFrame(.horizontal) { length, _ in
                Self.tileWidth(length - margin * 2, aspect: aspect)
            }
        } else {
            content.frame(width: Self.tileWidth(legacyWidth - margin * 2, aspect: aspect))
        }
    }

    /// Portrait: about two thirds of the card width, so the next one shows;
    /// landscape: nearly all of it. Never taller than 560 pt (wide screens).
    nonisolated static func tileWidth(_ width: CGFloat, aspect: Double) -> CGFloat {
        let width = max(1, width) * (aspect < 1 ? 0.64 : 0.92)
        return min(width, CGFloat(560 * aspect))
    }

    private func load() async {
        await withTaskGroup(of: (URL, UIImage?).self) { group in
            for shot in screenshots where images[shot.url] == nil {
                group.addTask { (shot.url, await ScreenshotCache.image(shot.url)) }
            }
            // Applied together, so the strip changes once.
            var loaded = images, missing = failed
            for await (url, image) in group {
                if let image { loaded[url] = image } else { missing.insert(url) }
            }
            // Left the page or tapped early: unloaded ones aren't failures.
            guard !Task.isCancelled else { return }
            images = loaded; failed = missing
        }
    }
}

/// Where a version row will be while the list loads.
private struct VersionRowSkeleton: View {
    var body: some View {
        HStack(spacing: 12) {
            VStack(alignment: .leading, spacing: 7) {
                RoundedRectangle(cornerRadius: 4).fill(Color(.tertiarySystemFill)).frame(width: 110, height: 15)
                RoundedRectangle(cornerRadius: 4).fill(Color(.quaternarySystemFill)).frame(width: 170, height: 11)
            }
            Spacer(minLength: 8)
            Capsule().fill(Color(.tertiarySystemFill)).frame(width: 74, height: 30)
        }
        .monochromeShimmer()
        .padding(.vertical, 2)
        .accessibilityHidden(true)
    }
}

/// The App Store's outline device glyph under the screenshots.
private struct DeviceGlyph: View {
    let platform: AppPlatform
    var body: some View {
        switch platform {
        case .iOS:
            RoundedRectangle(cornerRadius: 3, style: .continuous).stroke(lineWidth: 1.2).frame(width: 10, height: 17)
        case .iPadOS:
            RoundedRectangle(cornerRadius: 3, style: .continuous).stroke(lineWidth: 1.2).frame(width: 14, height: 18)
        default:
            Image(systemName: platform.symbol)
        }
    }
}

/// A titled group of rows on a rounded card, like an inset grouped list
/// section, or (plain) content straight on the page.
struct CardSection<Content: View, Header: View>: View {
    static var pageMargin: CGFloat { 16 }
    static var cornerRadius: CGFloat {
        if #available(iOS 26, *) { return 26 }
        return 10
    }
    var plain = false
    @ViewBuilder var content: Content
    @ViewBuilder var header: Header
    init(plain: Bool = false, @ViewBuilder content: () -> Content, @ViewBuilder header: () -> Header) {
        self.plain = plain; self.content = content(); self.header = header()
    }
    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            header.padding(.horizontal, Self.pageMargin + 20)
            if plain { content } else {
                _VariadicView.Tree(CardRows()) { content }
                    .labeledContentStyle(CardLabeledContentStyle())
                    .background(Color(.secondarySystemGroupedBackground),
                                in: RoundedRectangle(cornerRadius: Self.cornerRadius, style: .continuous))
                    .padding(.horizontal, Self.pageMargin)
            }
        }
    }
}
extension CardSection where Header == EmptyView {
    init(plain: Bool = false, @ViewBuilder content: () -> Content) {
        self.init(plain: plain, content: content) { EmptyView() }
    }
}

private struct CardRowInsetsKey: _ViewTraitKey {
    static var defaultValue: EdgeInsets? { nil }
}
extension View {
    /// Padding of this row inside a card (default: as in a list row).
    func cardRowInsets(_ insets: EdgeInsets) -> some View { _trait(CardRowInsetsKey.self, insets) }
}

/// Rows of a card with hairlines between them.
private struct CardRows: _VariadicView_UnaryViewRoot {
    func body(children: _VariadicView.Children) -> some View {
        let last = children.last?.id
        VStack(alignment: .leading, spacing: 0) {
            ForEach(children) { child in
                child
                    .padding(child[CardRowInsetsKey.self] ?? EdgeInsets(top: 11, leading: 20, bottom: 11, trailing: 20))
                    .frame(maxWidth: .infinity, minHeight: 44, alignment: .leading)
                if child.id != last { Divider().padding(.leading, 20) }
            }
        }
    }
}

/// Label on the left, value on the right, as in a list.
private struct CardLabeledContentStyle: LabeledContentStyle {
    func makeBody(configuration: Configuration) -> some View {
        HStack(alignment: .firstTextBaseline, spacing: 12) {
            configuration.label.foregroundStyle(.primary)
            Spacer(minLength: 12)
            configuration.content.foregroundStyle(.secondary).multilineTextAlignment(.trailing)
        }
    }
}

/// Screenshots already loaded by the strip, so the full-screen view opens
/// on them at once.
private enum ScreenshotCache {
    private actor Requests {
        var pending: [URL: Task<UIImage?, Never>] = [:]
        func image(_ url: URL) async -> UIImage? {
            if let image = cached(url) { return image }
            if let task = pending[url] { return await task.value }
            let task = Task.detached(priority: .utility) { () -> UIImage? in
                guard let (data, _) = try? await URLSession.shared.data(from: url), let image = UIImage(data: data) else { return nil }
                let pixelW = image.size.width * image.scale
                let pixelH = image.size.height * image.scale
                let maxDim: CGFloat = 1400
                if max(pixelW, pixelH) > maxDim {
                    let factor = maxDim / max(pixelW, pixelH)
                    let target = CGSize(width: max(1, (pixelW * factor).rounded()),
                                        height: max(1, (pixelH * factor).rounded()))
                    return await image.byPreparingThumbnail(ofSize: target) ?? image
                }
                return await image.byPreparingForDisplay() ?? image
            }
            pending[url] = task
            let image = await task.value
            if let image { cache.setObject(image, forKey: url as NSURL, cost: IconCache.cost(of: image)) }
            pending.removeValue(forKey: url)
            return image
        }
    }
    private static let requests = Requests()
    /// Decoded screenshots are large (up to 2000 px); keep a bounded amount.
    private static let cache: NSCache<NSURL, UIImage> = {
        let cache = NSCache<NSURL, UIImage>(); cache.totalCostLimit = 96 * 1024 * 1024; return cache
    }()
    static func cached(_ url: URL) -> UIImage? { cache.object(forKey: url as NSURL) }
    static func image(_ url: URL) async -> UIImage? {
        if let image = cached(url) { return image }
        return await requests.image(url)
    }
}

private struct ScreenshotTile: View {
    let image: UIImage?
    let failed: Bool
    var cornerRadius: CGFloat
    var body: some View {
        Rectangle().fill(Color(.tertiarySystemFill))
            .overlay { if failed { Image(systemName: "photo").foregroundStyle(.tertiary) } }
            .overlay {
                if let image {
                    Image(uiImage: image).resizable().scaledToFill().transition(.opacity)
                }
            }
            .animation(.easeOut(duration: 0.25), value: image != nil)
            .clipShape(RoundedRectangle(cornerRadius: cornerRadius, style: .continuous))
        .overlay(RoundedRectangle(cornerRadius: cornerRadius, style: .continuous).stroke(Color.primary.opacity(0.1), lineWidth: 0.5))
    }
}

/// Full-screen screenshots as in the App Store: one large screenshot in the
/// middle with its neighbours peeking in, swiped one at a time.
private struct ScreenshotViewer: View {
    let screenshots: [StoreService.Screenshot]
    let selection: StoreService.Screenshot
    @State private var current: StoreService.Screenshot.ID?
    @State private var images: [URL: UIImage] = [:]
    @Environment(\.dismiss) private var dismiss
    init(screenshots: [StoreService.Screenshot], selection: StoreService.Screenshot) {
        self.screenshots = screenshots; self.selection = selection
        _current = State(initialValue: selection.id)
    }
    private func aspect(_ shot: StoreService.Screenshot) -> Double {
        let fallback = (shot.aspect.isFinite && shot.aspect > 0) ? max(0.1, shot.aspect) : 0.5625
        guard let image = images[shot.url] ?? ScreenshotCache.cached(shot.url),
              image.size.width > 0, image.size.height > 0 else { return fallback }
        let ratio = Double(image.size.width / image.size.height)
        return (ratio.isFinite && ratio > 0) ? max(0.1, ratio) : fallback
    }
    var body: some View {
        GeometryReader { proxy in
            let height = max(1, proxy.size.height - 96)
            let widest = max(1, proxy.size.width - 64)
            // Each screenshot as large as fits, leaving room for the neighbours.
            let widths = screenshots.map { max(1, min(widest, height * aspect($0))) }
            let margin = max(24, (proxy.size.width - (widths.max() ?? widest)) / 2)
            if #available(iOS 17, *) {
                ScrollViewReader { reader in
                    ScrollView(.horizontal, showsIndicators: false) {
                        HStack(spacing: 12) {
                            ForEach(Array(zip(screenshots, widths)), id: \.0.id) { shot, width in
                                let ratio = aspect(shot)
                                ScreenshotTile(image: images[shot.url] ?? ScreenshotCache.cached(shot.url), failed: false,
                                               cornerRadius: ratio < 1 ? 28 : 18)
                                    .frame(width: width, height: width / ratio)
                                    .frame(maxHeight: .infinity)
                                    .id(shot.id)
                            }
                        }
                        .scrollTargetLayout()
                    }
                    .contentMargins(.horizontal, margin, for: .scrollContent)
                    .scrollTargetBehavior(.viewAligned(limitBehavior: .always))
                    .scrollPosition(id: $current)
                    .padding(.top, 72).padding(.bottom, 24)
                    .onAppear { reader.scrollTo(selection.id, anchor: .center) }
                }
            } else {
                TabView(selection: $current) {
                    ForEach(screenshots) { shot in
                        let ratio = aspect(shot)
                        let width = max(1, min(widest, height * ratio))
                        ScreenshotTile(image: images[shot.url] ?? ScreenshotCache.cached(shot.url), failed: false,
                                       cornerRadius: ratio < 1 ? 28 : 18)
                            .frame(width: width, height: width / ratio)
                            .frame(maxWidth: .infinity, maxHeight: .infinity)
                            .tag(Optional(shot.id))
                    }
                }
                .tabViewStyle(.page(indexDisplayMode: .automatic))
                .padding(.top, 72).padding(.bottom, 24)
            }
        }
        .overlay(alignment: .topTrailing) {
            Button { dismiss() } label: {
                Image(systemName: "xmark").font(.title3.weight(.medium)).foregroundStyle(.primary)
                    .frame(width: 48, height: 48).background(.regularMaterial, in: Circle())
                    .overlay(Circle().stroke(Color.primary.opacity(0.08), lineWidth: 0.5))
            }
            .padding(.trailing, 16).padding(.top, 8)
            .accessibilityLabel("关闭")
        }
        .background(Color(.systemBackground).ignoresSafeArea())
        .task(id: screenshots.map(\.url)) {
            for shot in screenshots where images[shot.url] == nil {
                if let image = await ScreenshotCache.image(shot.url) { images[shot.url] = image }
            }
        }
        .onDisappear { images.removeAll() }
    }
}

extension View {
    /// Where a full-screen view zooms out of and back into (iOS 18 and later).
    @ViewBuilder func zoomSource(_ id: some Hashable, in namespace: Namespace.ID) -> some View {
        if #available(iOS 18, *) { matchedTransitionSource(id: id, in: namespace) } else { self }
    }
    @ViewBuilder func zoomTransition(_ id: some Hashable, in namespace: Namespace.ID) -> some View {
        if #available(iOS 18, *) { navigationTransition(.zoom(sourceID: id, in: namespace)) } else { self }
    }
}

/// Small cards for the developer's other apps, opening their own pages.
private struct DeveloperAppsStrip: View {
    let apps: [StoreApp]
    var body: some View {
        ScrollView(.horizontal, showsIndicators: false) {
            LazyHStack(alignment: .top, spacing: 14) {
                ForEach(apps) { app in
                    NavigationLink { AppDetailView(app: app) } label: {
                        VStack(alignment: .leading, spacing: 6) {
                            AppIcon(url: app.iconURL, size: 76)
                            Text(app.name).font(.caption.weight(.medium)).foregroundStyle(.primary)
                                .lineLimit(2).multilineTextAlignment(.leading)
                            if !app.displayCategory.isEmpty {
                                Text(app.displayCategory).font(.caption2).foregroundStyle(.secondary).lineLimit(1)
                            }
                        }
                        .frame(width: 84, alignment: .leading)
                    }
                    .buttonStyle(.plain)
                }
            }
            .compatibleScrollTargetLayout()
            .legacyHorizontalPadding(20)
            .padding(.vertical, 16)
        }
        .compatibleHorizontalScrollMargins(20)
        .compatibleViewAlignedScrolling()
        .clipShape(RoundedRectangle(cornerRadius: CardSection<EmptyView, EmptyView>.cornerRadius, style: .continuous))
        .accessibilityIdentifier("detail.developer-apps")
    }
}

private extension View {
    @ViewBuilder func measureLegacyWidth(_ width: Binding<CGFloat>) -> some View {
        if #available(iOS 17, *) { self }
        else { onGeometryChange(for: CGFloat.self) { $0.size.width } action: { width.wrappedValue = $0 } }
    }
}

@MainActor
private final class DetailHeaderScrollObserver: ObservableObject {
    @Published var scrolledAway = false
}

private struct DetailToolbarPrincipalIcon: View {
    @ObservedObject var observer: DetailHeaderScrollObserver
    let url: URL?

    var body: some View {
        AppIcon(url: url, size: 30)
            .opacity(observer.scrolledAway ? 1 : 0)
            .animation(.easeInOut(duration: 0.18), value: observer.scrolledAway)
            .accessibilityHidden(true)
    }
}

@MainActor
private final class VersionMetadataBox: ObservableObject {
    var metadata: [String: VersionMetadata] = [:]
    var versionsSnapshot: [AppVersion] = []
    var releaseNotesSnapshot: [String: ReleaseNote] = [:]

    func clear() {
        metadata.removeAll()
        versionsSnapshot.removeAll()
    }

    func replaceAll(_ values: [String: VersionMetadata]) {
        metadata = values
    }
}

@MainActor
private final class VersionScrollGate: ObservableObject {
    private var activeScroll = false
    private var settleTask: Task<Void, Never>?
    private var waiters: [UUID: CheckedContinuation<Void, Error>] = [:]

    var isScrolling: Bool { activeScroll || settleTask != nil }

    func setScrolling(_ active: Bool) {
        if active {
            activeScroll = true
            settleTask?.cancel()
            settleTask = nil
        } else {
            activeScroll = false
            settleTask?.cancel()
            settleTask = Task { [weak self] in
                do { try await Task.sleep(nanoseconds: 120_000_000) } catch { return }
                self?.releaseWaiters()
            }
        }
    }

    func reset() {
        activeScroll = false
        settleTask?.cancel()
        releaseWaiters()
    }

    func waitUntilSettled() async throws {
        try Task.checkCancellation()
        guard isScrolling else { return }
        let id = UUID()
        try await withTaskCancellationHandler {
            try await withCheckedThrowingContinuation { (continuation: CheckedContinuation<Void, Error>) in
                if Task.isCancelled {
                    continuation.resume(throwing: CancellationError())
                    return
                }
                if !isScrolling {
                    continuation.resume()
                    return
                }
                waiters[id] = continuation
            }
        } onCancel: {
            Task { @MainActor [weak self] in
                self?.cancelWaiter(id)
            }
        }
    }

    private func releaseWaiters() {
        settleTask = nil
        guard !activeScroll else { return }
        let pending = waiters
        waiters.removeAll()
        for continuation in pending.values { continuation.resume() }
    }

    private func cancelWaiter(_ id: UUID) {
        guard let continuation = waiters.removeValue(forKey: id) else { return }
        continuation.resume(throwing: CancellationError())
    }
}

private extension View {
    @ViewBuilder
    func compatibleScrollPhaseTracking(_ gate: VersionScrollGate) -> some View {
        if #available(iOS 18, *) {
            onScrollPhaseChange { _, phase in
                gate.setScrolling(phase == .interacting || phase == .tracking || phase == .decelerating)
            }
        } else {
            self
        }
    }
}

/// Isolates loading spinner, metadata state, and thumbnail state to a single row so
/// loading uncached version entries never invalidates `AppDetailView` or sibling rows.
private struct VersionRowView: View {
    @Environment(\.dynamicTypeSize) private var dynamicTypeSize
    let store: ToolStore
    let app: StoreApp
    let version: AppVersion
    let initialMetadata: VersionMetadata?
    let resolvedNote: ReleaseNote?
    let cacheKey: String
    let isVisualPreview: Bool
    let isExpanded: Bool
    let translatedNote: String?
    let showHistoryIcons: Bool
    let supportsIPA: Bool
    let readsMetadata: Bool
    let versionsKey: String
    let versionsStale: Bool
    let scrollGate: VersionScrollGate
    let metadataBox: VersionMetadataBox
    let onToggleNote: () -> Void
    let onTranslateNote: (String?) -> Void
    let onCopy: (String) -> Void
    let onEnqueued: () -> Void
    let onVersionResolved: () -> Void
    let onAuthFailure: () -> Void
    let onFailure: () -> Void
    let onSuccess: () -> Void

    @State private var liveMetadata: VersionMetadata?
    @State private var isLoading = false
    @State private var loadedContext = ""

    var body: some View {
        let info = (loadedContext == versionsKey ? liveMetadata : nil) ?? initialMetadata
        let name = AppDetailView.displayVersion(version, info: info)
        let known = name != AppVersion.unknown
        let reading = !known && isLoading
        let note = known ? (resolvedNote ?? metadataBox.releaseNotesSnapshot[name]) : nil
        let date = (info?.released ?? note?.date)?.formatted(AppDetailView.releaseDateFormat)
        let estimatedDate = info?.released != nil && info?.releaseDateIsEstimated != false
        let size = info?.packageSize.map { $0.byteLabel }
        let readingSize = size == nil && isLoading

        HStack(alignment: .top, spacing: 12) {
            if supportsIPA && showHistoryIcons {
                VersionHistoryIcon(
                    versionID: version.id,
                    cacheKey: cacheKey,
                    isVisualPreview: isVisualPreview,
                    available: info?.hasUnverifiedMissingIcon == true ? nil : info?.iconAvailable,
                    loading: isLoading,
                    context: versionsKey,
                    loadImage: { await store.cachedVersionImage(app: app, versionID: version.id) }
                )
            }
            VStack(alignment: .leading, spacing: 6) {
                if dynamicTypeSize.isAccessibilitySize {
                    VStack(alignment: .leading, spacing: 8) { headerContent(name: name, known: known, reading: reading) }
                } else {
                    HStack(alignment: .firstTextBaseline, spacing: 12) { headerContent(name: name, known: known, reading: reading) }
                }
                if let bundleNote = AppDetailView.bundleVersionSubtitle(version, displayed: name, info: info) {
                    Text(verbatim: bundleNote)
                        .font(.caption.monospacedDigit()).foregroundStyle(.secondary)
                        .fixedSize(horizontal: false, vertical: true)
                }
                if dynamicTypeSize.isAccessibilitySize {
                    VStack(alignment: .leading, spacing: 4) { factsContent(date: date, estimatedDate: estimatedDate, size: size, readingSize: readingSize) }
                        .font(.caption.monospacedDigit()).foregroundStyle(.secondary)
                    VStack(alignment: .leading, spacing: 4) { idNotesContent(note: note) }
                } else {
                    HStack(alignment: .firstTextBaseline, spacing: 12) { factsContent(date: date, estimatedDate: estimatedDate, size: size, readingSize: readingSize) }
                        .font(.caption.monospacedDigit()).foregroundStyle(.secondary)
                    HStack(alignment: .firstTextBaseline, spacing: 8) { idNotesContent(note: note) }
                }
                if let note, !note.text.isEmpty, isExpanded {
                    Text(translatedNote ?? note.text).font(.footnote).foregroundStyle(.secondary)
                        .textSelection(.enabled).fixedSize(horizontal: false, vertical: true)
                    if TranslateButton.offered(for: note.text, translation: translatedNote) {
                        TranslateButton(text: note.text, translation: Binding(
                            get: { translatedNote }, set: { onTranslateNote($0) }))
                            .font(.caption.weight(.medium)).buttonStyle(.borderless)
                            .accessibilityIdentifier("detail.version.translate." + version.id)
                    }
                }
            }
        }
        .padding(.vertical, 2)
        .frame(maxWidth: .infinity, alignment: .leading)
        .contentShape(Rectangle())
        .transaction { $0.animation = nil }
        .contextMenu {
            if known {
                Button("复制版本号", systemImage: "number") { onCopy(name) }
                    .accessibilityIdentifier("detail.version.copy-number." + version.id)
            }
            Button("复制版本 ID", systemImage: "doc.on.doc") { onCopy(version.id) }
                .accessibilityIdentifier("detail.version.copy-id." + version.id)
        }
        .task(id: "\(version.id)-\(versionsKey)-\(readsMetadata)-\(versionsStale)-\(showHistoryIcons)") {
            await loadMetadataIfNeeded()
        }
    }

    @ViewBuilder
    private func headerContent(name: String, known: Bool, reading: Bool) -> some View {
        Text(known ? "版本 \(name)" : reading ? "版本 0.0.0" : "未知版本")
            .font(.body.weight(.semibold))
            .redacted(reason: reading ? .placeholder : [])
            .fixedSize(horizontal: false, vertical: true)
            .frame(maxWidth: .infinity, alignment: .leading)
            .accessibilityIdentifier("detail.version.number." + version.id)
        StoreDownloadActionButton(
            app: app,
            versionID: version.id,
            marketingVersion: known ? name : nil,
            idleTitle: "下载",
            filled: false,
            alignment: .center,
            idleAccessibilityLabel: known ? AppText.text("下载版本 \(name)") : AppText.text("下载版本 ID \(version.id)"),
            onEnqueued: onEnqueued
        )
        .fixedSize()
    }

    @ViewBuilder
    private func factsContent(date: String?, estimatedDate: Bool, size: String?, readingSize: Bool) -> some View {
        if let date {
            Text(estimatedDate ? LocalizedStringKey("包内日期：\(date)") : LocalizedStringKey("\(date)"))
                .accessibilityIdentifier("detail.version.date." + version.id)
        }
        if supportsIPA {
            Text(verbatim: "IPA · " + (size ?? (readingSize ? "000 MB" : "—")))
                .redacted(reason: readingSize ? .placeholder : [])
                .accessibilityLabel(Text("安装包大小") + Text(verbatim: " " + (size ?? "—")))
                .accessibilityIdentifier("detail.version.size." + version.id)
        }
    }

    @ViewBuilder
    private func idNotesContent(note: ReleaseNote?) -> some View {
        Text("版本 ID \(version.id)")
            .font(.caption.monospacedDigit()).foregroundStyle(.tertiary)
            .lineLimit(dynamicTypeSize.isAccessibilitySize ? nil : 1)
            .minimumScaleFactor(dynamicTypeSize.isAccessibilitySize ? 1.0 : 0.85)
            .fixedSize(horizontal: false, vertical: true)
            .frame(maxWidth: .infinity, alignment: .leading)
            .accessibilityIdentifier("detail.version.id." + version.id)
        if let note, !note.text.isEmpty {
            Button(action: onToggleNote) {
                HStack(spacing: 4) {
                    Text(isExpanded ? "收起更新说明" : "更新说明")
                        .transaction { $0.animation = nil }
                    Image(systemName: "chevron.down").rotationEffect(.degrees(isExpanded ? 180 : 0))
                }
                .font(.caption.weight(.medium))
                .contentShape(Rectangle())
            }
            .buttonStyle(.borderless)
            .fixedSize()
            .accessibilityIdentifier("detail.version.notes." + version.id)
        }
    }

    private static func needsMetadataLoad(
        version: AppVersion,
        info: VersionMetadata?,
        supportsIPA: Bool,
        showIcons: Bool,
        cacheKey: String,
        isVisualPreview: Bool
    ) -> Bool {
        guard let info else { return true }
        if supportsIPA {
            if info.packageSize == nil { return true }
            if showIcons {
                if info.iconAvailable == nil || info.hasUnverifiedMissingIcon { return true }
                if info.iconAvailable == true, !isVisualPreview, VersionIconCache.cached(cacheKey) == nil {
                    return true
                }
            }
        }
        let pref = VersionService.versionPreference(info.version, rejectingID: version.id)
        return pref < 2 && info.ticketChecked != true
    }

    private func applyResolved(_ incoming: VersionMetadata, notifySearch: Bool) {
        let versions = metadataBox.versionsSnapshot
        let rowIndex = versions.firstIndex(where: { $0.id == version.id })
        let platform = store.settings.store.platform
        let appID = app.id
        let outcome = AppDetailView.reconciledMetadataEntry(
            incoming: incoming,
            version: version,
            rowIndex: rowIndex,
            currentMeta: metadataBox.metadata[version.id],
            appVersion: app.version,
            versions: versions,
            cachedMetadata: metadataBox.metadata,
            releaseNotes: metadataBox.releaseNotesSnapshot
        ) { upgraded in
            Task {
                await store.reconcileVersionNumber(
                    platform: platform, appID: appID, versionID: version.id,
                    version: upgraded, replaceStaleDotless: true
                )
            }
        }
        metadataBox.metadata[version.id] = outcome.metadata
        if liveMetadata != outcome.metadata {
            liveMetadata = outcome.metadata
        }
        if notifySearch { onVersionResolved() }
    }

    private func loadMetadataIfNeeded() async {
        if loadedContext != versionsKey {
            liveMetadata = nil
            isLoading = false
            loadedContext = versionsKey
        }
        guard readsMetadata, !versionsStale else { return }
        let currentInfo = liveMetadata ?? metadataBox.metadata[version.id] ?? initialMetadata
        guard Self.needsMetadataLoad(
            version: version, info: currentInfo, supportsIPA: supportsIPA,
            showIcons: showHistoryIcons, cacheKey: cacheKey, isVisualPreview: isVisualPreview
        ) else {
            if liveMetadata == nil, let currentInfo { liveMetadata = currentInfo }
            return
        }
        // Let fast-scrolled rows pass untouched and wait until active scrolling stops.
        do {
            try await Task.sleep(nanoseconds: 180_000_000)
            try await scrollGate.waitUntilSettled()
        } catch {
            return
        }
        guard !Task.isCancelled, !versionsStale else { return }
        if let satisfied = await store.cachedSatisfiedVersionMetadata(
            app: app, versionID: version.id, requiringIcon: showHistoryIcons
        ) {
            guard !Task.isCancelled else { return }
            applyResolved(satisfied, notifySearch: false)
            return
        }
        let latestInfo = liveMetadata ?? metadataBox.metadata[version.id] ?? initialMetadata
        guard !Task.isCancelled,
              Self.needsMetadataLoad(
                  version: version, info: latestInfo, supportsIPA: supportsIPA,
                  showIcons: showHistoryIcons, cacheKey: cacheKey, isVisualPreview: isVisualPreview
              ) else { return }
        isLoading = true
        defer { isLoading = false }
        do {
            let value = try await store.versionMetadata(
                app: app,
                versionID: version.id,
                includingIcon: showHistoryIcons,
                knownVersion: version.version,
                knownVersions: metadataBox.versionsSnapshot
            ) { partial in
                guard !Task.isCancelled else { return }
                applyResolved(partial, notifySearch: false)
            }
            guard !Task.isCancelled else { return }
            applyResolved(value, notifySearch: true)
            onSuccess()
        } catch {
            if Task.isCancelled || error is CancellationError { return }
            if error is AppleAuthError || error is AppleLoginError {
                onAuthFailure()
                return
            }
            onFailure()
        }
    }
}

/// Renders cached thumbnails synchronously from `VersionIconCache` on frame 0 and debounces
/// disk reads/decodes so high-speed scrolling never drops frames.
private struct VersionHistoryIcon: View {
    let versionID: String
    let cacheKey: String
    let isVisualPreview: Bool
    let available: Bool?
    let loading: Bool
    let context: String
    let loadImage: @Sendable () async -> UIImage?
    @State private var image: UIImage?
    @State private var loadedImageKey: String?

    var body: some View {
        let memoryImage = isVisualPreview ? nil : VersionIconCache.cached(cacheKey)
        let displayedImage = memoryImage ?? (loadedImageKey == cacheKey ? image : nil)

        ZStack {
            if let displayedImage {
                Image(uiImage: displayedImage).resizable().scaledToFit()
            } else {
                RoundedRectangle(cornerRadius: 11, style: .continuous).fill(Color.secondary.opacity(0.10))
                if loading { ProgressView().controlSize(.small) }
                else { Image(systemName: "app.dashed").font(.title2).foregroundStyle(.secondary) }
            }
        }
        .frame(width: 48, height: 48)
        .clipShape(RoundedRectangle(cornerRadius: 11, style: .continuous))
        .accessibilityElement(children: .ignore)
        .accessibilityLabel(displayedImage == nil ? Text("未获取该版本图标") : Text("该版本应用图标"))
        .accessibilityIdentifier((displayedImage == nil ? "detail.version.icon-missing." : "detail.version.icon.") + versionID)
        .task(id: "\(context)-\(versionID)-\(available == true)") {
            if memoryImage != nil {
                if image != nil { image = nil }
                if loadedImageKey != nil { loadedImageKey = nil }
                return
            }
            if loadedImageKey != cacheKey, image != nil { image = nil }
            guard available == true else {
                if image != nil { image = nil }
                loadedImageKey = nil
                return
            }
            if !isVisualPreview {
                // Skip disk reads and PNG decoding while rows fly past during fast scroll.
                do { try await Task.sleep(nanoseconds: 75_000_000) } catch { return }
                guard !Task.isCancelled else { return }
            }
            let decoded = await loadImage()
            guard !Task.isCancelled else { return }
            image = decoded
            loadedImageKey = cacheKey
        }
        .onDisappear {
            if image != nil { image = nil }
            loadedImageKey = nil
        }
    }
}
