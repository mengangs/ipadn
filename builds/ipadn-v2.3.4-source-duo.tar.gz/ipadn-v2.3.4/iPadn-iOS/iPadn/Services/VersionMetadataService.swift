import Foundation
import CryptoKit
import UIKit

/// The version number, date and package size of one App Store version, read from the
/// package itself (ipatool's get-version-metadata).
struct VersionMetadata: Codable, Hashable, Sendable {
    static let currentSchema = 4

    var version: String
    var released: Date?
    /// nil in legacy caches; those dates must also be treated as approximate.
    var releaseDateIsEstimated: Bool? = nil
    /// Complete remote IPA length, not the extracted app or an individual ZIP entry.
    /// Optional so caches written before size support remain readable.
    var packageSize: Int64? = nil
    /// nil: not checked/retryable; false: no readable primary PNG; true: cached PNG.
    var iconAvailable: Bool? = nil
    /// nil in legacy caches; ensures dotless versions written solely from IPA Info.plist
    /// are reconciled once against Apple's DownloadDispatch ticket metadata.
    var ticketChecked: Bool? = nil
    /// nil in legacy caches created before stale latest-version fallback filtering.
    var metadataSchema: Int? = nil
    /// Raw `Info.plist` `CFBundleShortVersionString`, preserved separately from the
    /// App Store public marketing version (e.g. `10.0.22` when Store says `1.9.5`).
    var bundleShortVersion: String? = nil
    /// Raw `Info.plist` `CFBundleVersion` build number (e.g. `80`, `48000`).
    var buildVersion: String? = nil

    /// True when an older build cached `iconAvailable == false` after `RemoteZip` failed
    /// before reading `Info.plist` (leaving both `released` and `buildVersion` nil).
    var hasUnverifiedMissingIcon: Bool {
        iconAvailable == false && released == nil && buildVersion == nil && ticketChecked == true
    }
}

/// Reads byte ranges of a remote file.
protocol RangeReader: Sendable {
    /// The last `count` bytes and the size of the whole file.
    func tail(_ count: Int) async throws -> (data: Data, size: Int64)
    func read(offset: Int64, count: Int) async throws -> Data
}

struct HTTPRangeReader: RangeReader {
    let url: URL
    /// Largest single range: big enough for the central directory of large
    /// games, small enough that a misbehaving server cannot exhaust memory.
    static let limit = 32 * 1024 * 1024

    func tail(_ count: Int) async throws -> (data: Data, size: Int64) {
        let (data, contentRange) = try await HTTPClient.shared.range(url, "-\(count)", limit: count)
        // "bytes 100-199/200"
        guard let total = contentRange.split(separator: "/").last.flatMap({ Int64($0) }), total > 0 else {
            throw RemoteZip.Failure.unreadable
        }
        return (data, total)
    }

    func read(offset: Int64, count: Int) async throws -> Data {
        guard count > 0 else { return Data() }
        let (data, _) = try await HTTPClient.shared.range(url, "\(offset)-\(offset + Int64(count) - 1)", limit: count)
        guard data.count == count else { throw RemoteZip.Failure.unreadable }
        return data
    }
}

/// Reads one file out of a remote ZIP (an IPA) with a few range requests
/// instead of downloading the whole package.
enum RemoteZip {
    enum Failure: Error { case unreadable, notFound }

    struct Entry {
        var name: String
        var method: UInt16
        var compressedSize: Int64
        var size: Int64
        var localOffset: Int64
        var modified: Date?
    }

    /// The main app's Info.plist: version number and, as ipatool does, the
    /// release date it records or else the file's timestamp in the archive.
    static func versionMetadata(_ reader: RangeReader) async throws -> VersionMetadata {
        try await versionResources(reader, includingIcon: false).metadata
    }

    static func versionResources(_ reader: RangeReader, includingIcon: Bool = true,
                                 preferredVersion: String? = nil,
                                 onMetadata: (@Sendable (VersionMetadata) async -> Void)? = nil) async throws
        -> (metadata: VersionMetadata, icon: Data?) {
        let (entries, size) = try await centralDirectory(reader, filterForVersionResources: true)
        guard let entry = entries.first(where: { isMainInfoPlist($0.name) }) else { throw Failure.notFound }
        let data = try await contents(of: entry, fileSize: size, reader: reader)
        guard let plist = try PropertyListSerialization.propertyList(from: data, format: nil) as? [String: Any] else {
            throw Failure.unreadable
        }
        let rawShort = plistString(plist["CFBundleShortVersionString"] ?? plist["bundleShortVersionString"])
            .trimmingCharacters(in: .whitespacesAndNewlines)
        let rawBuild = plistString(plist["CFBundleVersion"] ?? plist["bundleVersion"])
            .trimmingCharacters(in: .whitespacesAndNewlines)
        let plistCandidate = VersionService.reconcileTicketVersion(shortVersion: rawShort, buildVersion: rawBuild)
        let sanitizedPlist = VersionService.sanitizedVersion(plistCandidate)
        let plistScore = VersionService.versionPreference(sanitizedPlist)
        let sanitizedPref = preferredVersion.map { VersionService.sanitizedVersion($0) } ?? AppVersion.unknown
        let prefScore = VersionService.versionPreference(sanitizedPref)
        let version: String
        if prefScore > plistScore {
            version = sanitizedPref
        } else if sanitizedPlist != AppVersion.unknown {
            version = sanitizedPlist
        } else if sanitizedPref != AppVersion.unknown {
            version = sanitizedPref
        } else {
            version = !rawShort.isEmpty ? rawShort : rawBuild
        }
        guard !version.isEmpty else { throw Failure.unreadable }
        let explicitDate = releaseDate(plist["releaseDate"] ?? plist["ReleaseDate"])
        var metadata = VersionMetadata(version: version,
                                       released: explicitDate ?? entry.modified,
                                       releaseDateIsEstimated: explicitDate == nil,
                                       packageSize: size,
                                       ticketChecked: preferredVersion != nil ? true : nil,
                                       metadataSchema: VersionMetadata.currentSchema,
                                       bundleShortVersion: rawShort.isEmpty ? nil : rawShort,
                                       buildVersion: rawBuild.isEmpty ? nil : rawBuild)
        await onMetadata?(metadata)
        try Task.checkCancellation()
        var icon: Data?
        if includingIcon {
            do {
                for candidate in primaryIconEntries(entries, infoPath: entry.name, plist: plist).prefix(4) {
                    try Task.checkCancellation()
                    let bytes = try await contents(of: candidate, fileSize: size, reader: reader)
                    if let png = PackageIconService.normalizedArtwork(bytes, maximumPixels: 144) { icon = png; break }
                }
                metadata.iconAvailable = icon != nil
            } catch is CancellationError { throw CancellationError() }
            catch { /* Keep useful version/size; a failed icon read remains retryable. */ }
        }
        return (metadata, icon)
    }

    /// Only the declared PRIMARY icon in the same main app. Never extensions,
    /// alternate icons, store artwork, or an unsafe Assets.car bundle load.
    static func primaryIconEntries(_ entries: [Entry], infoPath: String, plist: [String: Any]) -> [Entry] {
        let phone = (plist["CFBundleIcons"] as? [String: Any])?["CFBundlePrimaryIcon"] as? [String: Any]
        let pad = (plist["CFBundleIcons~ipad"] as? [String: Any])?["CFBundlePrimaryIcon"] as? [String: Any]
        let declared = (phone?["CFBundleIconFiles"] as? [String]).flatMap { $0.isEmpty ? nil : $0 }
            ?? (plist["CFBundleIconFiles"] as? [String]).flatMap { $0.isEmpty ? nil : $0 }
            ?? (pad?["CFBundleIconFiles"] as? [String]) ?? []
        let names = (declared + [plistString(plist["CFBundleIconFile"])])
            .filter { !$0.isEmpty && !$0.contains("/") && !$0.contains("\\") }
            .map { ($0 as NSString).deletingPathExtension.lowercased() }
        let prefix = String(infoPath.dropLast("Info.plist".count))
        return entries.filter { entry in
            guard entry.name.hasPrefix(prefix), entry.compressedSize > 0,
                  entry.compressedSize <= 2_000_000, entry.size <= 6_000_000 else { return false }
            let relative = String(entry.name.dropFirst(prefix.count)).lowercased()
            return !relative.contains("/") && relative.hasSuffix(".png") && names.contains {
                relative == $0 + ".png" || relative.hasPrefix($0 + "@") || relative.hasPrefix($0 + "~")
            }
        }.sorted {
            func score(_ name: String) -> Int { name.contains("@3x") ? 3 : name.contains("@2x") ? 2 : 1 }
            let a = score($0.name), b = score($1.name)
            return a == b ? $0.name < $1.name : a > b
        }
    }

    static func isMainInfoPlist(_ name: String) -> Bool {
        let parts = name.split(separator: "/", omittingEmptySubsequences: false)
        return parts.count == 3 && parts[0] == "Payload" && parts[1].hasSuffix(".app") && parts[2] == "Info.plist"
    }

    static func releaseDate(_ value: Any?) -> Date? {
        if let date = value as? Date { return date }
        if let number = value as? NSNumber { return Date(timeIntervalSince1970: number.doubleValue) }
        guard let text = (value as? String)?.trimmingCharacters(in: .whitespaces), !text.isEmpty else { return nil }
        let iso = ISO8601DateFormatter()
        if let date = iso.date(from: text) { return date }
        iso.formatOptions.insert(.withFractionalSeconds)
        if let date = iso.date(from: text) { return date }
        let formatter = DateFormatter()
        formatter.locale = Locale(identifier: "en_US_POSIX"); formatter.timeZone = TimeZone(secondsFromGMT: 0)
        for format in ["EEEE, MMMM d, yyyy", "yyyy-MM-dd"] {
            formatter.dateFormat = format
            if let date = formatter.date(from: text) { return date }
        }
        return nil
    }

    static func centralDirectory(_ reader: RangeReader, filterForVersionResources: Bool = false) async throws -> (entries: [Entry], size: Int64) {
        // End record (22 bytes) plus the longest possible comment.
        let (fetched, size) = try await reader.tail(22 + 65_535)
        let tail = Data(fetched)
        let tailStart = size - Int64(tail.count)
        guard let end = lastSignature(0x0605_4b50, in: tail), end + 22 <= tail.count else { throw Failure.unreadable }
        var count = Int64(tail.le16(end + 10))
        var directorySize = Int64(tail.le32(end + 12))
        var directoryOffset = Int64(tail.le32(end + 16))
        if count == 0xFFFF || directorySize == 0xFFFF_FFFF || directoryOffset == 0xFFFF_FFFF {
            // ZIP64: the locator sits right before the end record.
            let locator = end - 20
            guard locator >= 0, tail.le32(locator) == 0x0706_4b50,
                  let recordOffset = Int64(exactly: tail.le64(locator + 8)), recordOffset >= 0 else {
                throw Failure.unreadable
            }
            let record: Data
            let (recordTailDelta, deltaOverflow) = recordOffset.subtractingReportingOverflow(tailStart)
            let (recordEnd, endOverflow) = recordTailDelta.addingReportingOverflow(56)
            if recordOffset >= tailStart, !deltaOverflow, !endOverflow, recordEnd <= Int64(tail.count) {
                let start = Int(recordTailDelta)
                record = tail.subdata(in: start..<start + 56)
            } else {
                record = try await reader.read(offset: recordOffset, count: 56)
            }
            guard record.count >= 56, record.le32(0) == 0x0606_4b50,
                  let zCount = Int64(exactly: record.le64(32)), zCount >= 0,
                  let zSize = Int64(exactly: record.le64(40)),
                  let zOffset = Int64(exactly: record.le64(48)) else {
                throw Failure.unreadable
            }
            count = zCount
            directorySize = zSize
            directoryOffset = zOffset
        }
        let (directoryEnd, dirOverflow) = directoryOffset.addingReportingOverflow(directorySize)
        guard directorySize > 0, directorySize <= Int64(HTTPRangeReader.limit),
              directoryOffset >= 0, !dirOverflow, directoryEnd <= size else { throw Failure.unreadable }
        let directory: Data
        if directoryOffset >= tailStart {
            let start = Int(directoryOffset - tailStart)
            directory = tail.subdata(in: start..<start + Int(directorySize))
        } else {
            directory = try await reader.read(offset: directoryOffset, count: Int(directorySize))
        }
        return (try entries(directory, count: count, filterForVersionResources: filterForVersionResources), size)
    }

    private static let payloadPrefixBytes: [UInt8] = Array("Payload/".utf8)
    private static let infoPlistSuffixBytes: [UInt8] = Array("info.plist".utf8)
    private static let pngSuffixBytes: [UInt8] = Array(".png".utf8)
    private static let utcCalendar: Calendar = {
        var calendar = Calendar(identifier: .gregorian)
        calendar.timeZone = TimeZone(secondsFromGMT: 0)!
        return calendar
    }()

    private static func isVersionResourceCandidateName(_ slice: Data) -> Bool {
        guard slice.count > payloadPrefixBytes.count,
              slice.starts(with: payloadPrefixBytes) else { return false }
        var slashCount = 0
        for byte in slice where byte == 0x2F {
            slashCount += 1
            if slashCount > 2 { return false }
        }
        guard slashCount == 2 else { return false }
        return hasASCIICaseInsensitiveSuffix(slice, suffix: infoPlistSuffixBytes)
            || hasASCIICaseInsensitiveSuffix(slice, suffix: pngSuffixBytes)
    }

    private static func hasASCIICaseInsensitiveSuffix(_ slice: Data, suffix: [UInt8]) -> Bool {
        guard slice.count >= suffix.count else { return false }
        let start = slice.index(slice.endIndex, offsetBy: -suffix.count)
        for (offset, expected) in suffix.enumerated() {
            let actual = slice[slice.index(start, offsetBy: offset)]
            let lower = (actual >= 0x41 && actual <= 0x5A) ? (actual + 32) : actual
            if lower != expected { return false }
        }
        return true
    }

    static func entries(_ data: Data, count: Int64, filterForVersionResources: Bool = false) throws -> [Entry] {
        var result: [Entry] = []
        result.reserveCapacity(filterForVersionResources ? 24 : Int(min(count, 200_000)))
        var position = 0
        while position + 46 <= data.count, data.le32(position) == 0x0201_4b50 {
            let method = data.le16(position + 10)
            let dosTime = data.le16(position + 12), dosDate = data.le16(position + 14)
            var compressed = Int64(data.le32(position + 20))
            var size = Int64(data.le32(position + 24))
            let nameLength = Int(data.le16(position + 28))
            let extraLength = Int(data.le16(position + 30))
            let commentLength = Int(data.le16(position + 32))
            var offset = Int64(data.le32(position + 42))
            let nameStart = position + 46
            let extraStart = nameStart + nameLength
            let next = extraStart + extraLength + commentLength
            guard next <= data.count else { throw Failure.unreadable }
            let nameSlice = data[nameStart..<extraStart]
            if filterForVersionResources && !isVersionResourceCandidateName(nameSlice) {
                position = next
                continue
            }
            let name = String(data: nameSlice, encoding: .utf8) ?? String(data: nameSlice, encoding: .isoLatin1) ?? ""
            var modified = (!filterForVersionResources || isMainInfoPlist(name)) ? dosDateTime(date: dosDate, time: dosTime) : nil
            var extra = extraStart
            while extra + 4 <= extraStart + extraLength {
                let id = data.le16(extra), length = Int(data.le16(extra + 2))
                let body = extra + 4
                guard body + length <= extraStart + extraLength else { break }
                if id == 0x0001 {
                    // ZIP64 sizes and offset, present only for fields set to 0xFFFFFFFF.
                    var field = body
                    if size == 0xFFFF_FFFF, field + 8 <= body + length {
                        guard let v = Int64(exactly: data.le64(field)) else { throw Failure.unreadable }
                        size = v; field += 8
                    }
                    if compressed == 0xFFFF_FFFF, field + 8 <= body + length {
                        guard let v = Int64(exactly: data.le64(field)) else { throw Failure.unreadable }
                        compressed = v; field += 8
                    }
                    if offset == 0xFFFF_FFFF, field + 8 <= body + length {
                        guard let v = Int64(exactly: data.le64(field)) else { throw Failure.unreadable }
                        offset = v
                    }
                } else if id == 0x5455, length >= 5, data[data.startIndex + body] & 1 != 0,
                          !filterForVersionResources || isMainInfoPlist(name) {
                    modified = Date(timeIntervalSince1970: TimeInterval(Int32(bitPattern: data.le32(body + 1))))
                }
                extra = body + length
            }
            result.append(Entry(name: name, method: method, compressedSize: compressed, size: size,
                                localOffset: offset, modified: modified))
            position = next
        }
        return result
    }

    static func contents(of entry: Entry, fileSize: Int64, reader: RangeReader) async throws -> Data {
        // Info.plist is a few kilobytes; refuse anything implausible.
        guard entry.compressedSize >= 0, entry.compressedSize <= 4 * 1024 * 1024,
              entry.size >= 0, entry.size <= 16 * 1024 * 1024,
              entry.localOffset >= 0, entry.localOffset < fileSize else { throw Failure.unreadable }
        // Header, name and some room for its extra field; never past the end
        // of the file (the entry may be the last one).
        let guess = Int64(30 + entry.name.utf8.count + 256) + entry.compressedSize
        var data = try await reader.read(offset: entry.localOffset, count: Int(min(guess, fileSize - entry.localOffset)))
        guard data.count >= 30, data.le32(0) == 0x0403_4b50 else { throw Failure.unreadable }
        let start = 30 + Int(data.le16(26)) + Int(data.le16(28))
        let end = start + Int(entry.compressedSize)
        if end > data.count {
            guard entry.localOffset + Int64(end) <= fileSize else { throw Failure.unreadable }
            data += try await reader.read(offset: entry.localOffset + Int64(data.count), count: end - data.count)
        }
        let body = data.subdata(in: start..<end)
        switch entry.method {
        case 0: return body
        case 8:
            // Apple's zlib codec is raw DEFLATE, as ZIP stores it.
            let inflated = try (body as NSData).decompressed(using: .zlib) as Data
            guard inflated.count == entry.size else { throw Failure.unreadable }
            return inflated
        default: throw Failure.unreadable
        }
    }

    private static func lastSignature(_ signature: UInt32, in data: Data) -> Int? {
        var index = data.count - 22
        while index >= 0 {
            if data.le32(index) == signature { return index }
            index -= 1
        }
        return nil
    }

    /// DOS date and time, read as UTC like ipatool (Go's archive/zip).
    private static func dosDateTime(date: UInt16, time: UInt16) -> Date? {
        guard date != 0 else { return nil }
        var parts = DateComponents()
        parts.year = 1980 + Int(date >> 9); parts.month = Int((date >> 5) & 0xF); parts.day = Int(date & 0x1F)
        parts.hour = Int(time >> 11); parts.minute = Int((time >> 5) & 0x3F); parts.second = Int(time & 0x1F) * 2
        return utcCalendar.date(from: parts)
    }
}

private extension Data {
    func le16(_ offset: Int) -> UInt16 {
        let base = startIndex + offset
        return UInt16(self[base]) | UInt16(self[base + 1]) << 8
    }
    func le32(_ offset: Int) -> UInt32 {
        UInt32(le16(offset)) | UInt32(le16(offset + 2)) << 16
    }
    func le64(_ offset: Int) -> UInt64 {
        UInt64(le32(offset)) | UInt64(le32(offset + 4)) << 32
    }
}

/// Lock-free memory + concurrent background PNG decode cache for version icons,
/// kept outside `VersionMetadataStore` so disk metadata saves and network fetches
/// never block icon scrolling on the main thread.
enum VersionIconCache {
    private actor Requests {
        var pending: [String: Task<UIImage?, Never>] = [:]
        func load(_ key: String) async -> UIImage? {
            if let hit = VersionIconCache.cached(key) { return hit }
            if let task = pending[key] { return await task.value }
            let task = Task.detached(priority: .utility) { () -> UIImage? in
                let url = VersionMetadataStore.iconURL(key)
                guard let data = try? Data(contentsOf: url) else { return nil }
                return await VersionIconCache.prepareThumbnail(from: data)
            }
            pending[key] = task
            let image = await task.value
            if let image { VersionIconCache.store(image, for: key) }
            pending.removeValue(forKey: key)
            return image
        }
    }

    private static let requests = Requests()
    /// 24 MiB fits ~300 decoded 144x144px icons while bounding memory cleanly.
    private static let cache: NSCache<NSString, UIImage> = {
        let cache = NSCache<NSString, UIImage>()
        cache.totalCostLimit = 24 * 1024 * 1024
        return cache
    }()

    static func cost(of image: UIImage) -> Int {
        Int(image.size.width * image.scale * image.size.height * image.scale * 4)
    }

    static func cached(_ key: String) -> UIImage? {
        cache.object(forKey: key as NSString)
    }

    static func load(_ key: String) async -> UIImage? {
        if let hit = cached(key) { return hit }
        return await requests.load(key)
    }

    static func store(_ image: UIImage, for key: String) {
        cache.setObject(image, forKey: key as NSString, cost: cost(of: image))
    }

    static func remove(_ key: String) {
        cache.removeObject(forKey: key as NSString)
    }

    static func removeAll() {
        cache.removeAllObjects()
    }

    static func prepareThumbnail(from data: Data) async -> UIImage? {
        guard let image = UIImage(data: data) else { return nil }
        if let thumbnail = await image.byPreparingThumbnail(ofSize: CGSize(width: 144, height: 144)) {
            return thumbnail
        }
        return await image.byPreparingForDisplay() ?? image
    }
}

/// Version metadata never changes, so lookups are kept on disk. Lookups
/// run one at a time: each one asks Apple for a download ticket.
actor VersionMetadataStore {
    static let filename = "version-metadata.json"
    static let maxConcurrentFetches = 3
    private var cache = LocalResources.load([String: VersionMetadata].self, filename: VersionMetadataStore.filename) ?? [:]
    private var inFlight = 0
    private var waiters: [(UUID, CheckedContinuation<Void, Error>)] = []
    private let diskQueue = DispatchQueue(label: "ipadn.version-metadata.disk", qos: .utility)
    private var persistTask: Task<Void, Never>?

    static func key(platform: AppPlatform, appID: String, versionID: String) -> String {
        "\(platform.rawValue)|\(appID)|\(versionID)"
    }

    func cached(_ key: String) -> VersionMetadata? { cache[key] }
    func cached(_ keys: [String]) -> [String: VersionMetadata] {
        var found: [String: VersionMetadata] = [:]
        for key in keys { if let value = cache[key] { found[key] = value } }
        return found
    }

    func satisfiedCached(_ key: String, requiringPackageSize: Bool = false, requiringIcon: Bool = false) -> VersionMetadata? {
        guard let value = cache[key],
              satisfies(value, key: key, size: requiringPackageSize, icon: requiringIcon) else { return nil }
        return value
    }

    static func iconURL(_ key: String) -> URL {
        let name = SHA256.hash(data: Data(key.utf8)).map { String(format: "%02x", $0) }.joined()
        return LocalResources.support.appendingPathComponent("VersionIcons", isDirectory: true)
            .appendingPathComponent(name + ".png")
    }
    func icon(_ key: String) -> Data? { try? Data(contentsOf: Self.iconURL(key)) }

    /// Nonisolated so icon decoding never blocks behind metadata JSON writes or network lookups.
    nonisolated func image(_ key: String) async -> UIImage? {
        await VersionIconCache.load(key)
    }

    func saveIcon(_ data: Data, key: String) async throws {
        let url = Self.iconURL(key)
        let queue = diskQueue
        try await withCheckedThrowingContinuation { (continuation: CheckedContinuation<Void, Error>) in
            queue.async {
                do {
                    try FileManager.default.createDirectory(at: url.deletingLastPathComponent(), withIntermediateDirectories: true)
                    try data.write(to: url, options: .atomic)
                    continuation.resume()
                } catch {
                    continuation.resume(throwing: error)
                }
            }
        }
        VersionIconCache.remove(key)
        if let prepared = await Task.detached(priority: .utility, operation: { () -> UIImage? in
            guard let image = UIImage(data: data) else { return nil }
            let maxPixel = max(image.size.width * image.scale, image.size.height * image.scale)
            if maxPixel <= 144 {
                return await image.byPreparingForDisplay() ?? image
            }
            return await VersionIconCache.prepareThumbnail(from: data)
        }).value {
            VersionIconCache.store(prepared, for: key)
        }
    }

    /// Coalesces snapshot writes across bursts so scrolling does not clone and encode
    /// the full 5,000-entry metadata map after every individual row.
    private func persistSnapshot() {
        persistTask?.cancel()
        persistTask = Task { [weak self] in
            do { try await Task.sleep(nanoseconds: 600_000_000) } catch { return }
            await self?.flushSnapshot()
        }
    }

    func flushSnapshot() {
        persistTask?.cancel()
        persistTask = nil
        let snapshot = cache
        diskQueue.async {
            try? LocalResources.save(snapshot, filename: Self.filename)
        }
    }
    private func satisfies(_ value: VersionMetadata, key: String, size: Bool, icon: Bool) -> Bool {
        let pref = VersionService.versionPreference(value.version)
        let versionSettled = pref >= 2 || (value.ticketChecked == true && (pref >= 1 || (value.metadataSchema ?? 0) >= VersionMetadata.currentSchema))
        return versionSettled && (!size || value.packageSize != nil) && (!icon || (value.iconAvailable != nil && !value.hasUnverifiedMissingIcon &&
            (value.iconAvailable != true || FileManager.default.fileExists(atPath: Self.iconURL(key).path))))
    }

    static func versionID(from key: String) -> String? {
        key.split(separator: "|", maxSplits: 2).last.map(String.init)
    }

    func upgradeCachedVersion(_ key: String, version: String, replaceDotless: Bool = false) {
        guard var existing = cache[key] else { return }
        let rejectingID = Self.versionID(from: key)
        let incoming = VersionService.sanitizedVersion(version, rejectingID: rejectingID)
        let incomingScore = VersionService.versionPreference(incoming, rejectingID: rejectingID)
        let existingScore = VersionService.versionPreference(existing.version, rejectingID: rejectingID)
        if replaceDotless && incoming == AppVersion.unknown && existingScore <= 1 {
            cache.removeValue(forKey: key)
            persistSnapshot()
            return
        }
        let better: String
        if replaceDotless && existingScore <= 1 && incomingScore >= existingScore {
            better = incoming
        } else {
            better = VersionService.preferredVersion(version, over: existing.version, rejectingID: rejectingID)
        }
        guard better != existing.version || (replaceDotless && existing.metadataSchema != VersionMetadata.currentSchema) else { return }
        if existing.bundleShortVersion == nil,
           existingScore >= 2,
           better != existing.version {
            existing.bundleShortVersion = existing.version
        }
        existing.version = better
        if VersionService.versionPreference(better, rejectingID: rejectingID) >= 2 || replaceDotless {
            existing.metadataSchema = VersionMetadata.currentSchema
        }
        cache[key] = existing
        persistSnapshot()
    }

    func clearCache() throws {
        persistTask?.cancel()
        persistTask = nil
        cache.removeAll()
        VersionIconCache.removeAll()
        try diskQueue.sync {
            try LocalResources.save([String: VersionMetadata](), filename: Self.filename)
            let iconsDir = LocalResources.support.appendingPathComponent("VersionIcons", isDirectory: true)
            if FileManager.default.fileExists(atPath: iconsDir.path) {
                try? FileManager.default.removeItem(at: iconsDir)
            }
        }
    }

    private func reconciledCachedHit(for key: String, requiringPackageSize: Bool, requiringIcon: Bool,
                                     knownVersion: String?,
                                     allowCached: (VersionMetadata) -> Bool) -> VersionMetadata? {
        guard var value = cache[key],
              allowCached(value),
              satisfies(value, key: key, size: requiringPackageSize, icon: requiringIcon) else { return nil }
        if let knownVersion {
            let rejectingID = Self.versionID(from: key)
            let cleanKnown = VersionService.sanitizedVersion(knownVersion, rejectingID: rejectingID)
            let knownScore = VersionService.versionPreference(cleanKnown, rejectingID: rejectingID)
            let cachedScore = VersionService.versionPreference(value.version, rejectingID: rejectingID)
            if value.bundleShortVersion == nil,
               (value.metadataSchema ?? 0) < VersionMetadata.currentSchema,
               knownScore >= 2, cachedScore >= 2, cleanKnown != value.version {
                // Legacy schema stored `CFBundleShortVersionString` (e.g. 10.0.22) in `version`,
                // overwriting the public App Store marketing version (e.g. 1.9.5).
                value.bundleShortVersion = value.version
                value.version = cleanKnown
                value.metadataSchema = VersionMetadata.currentSchema
                cache[key] = value
                persistSnapshot()
                return value
            }
            let better = VersionService.preferredVersion(knownVersion, over: value.version, rejectingID: rejectingID)
            if better != value.version {
                if value.bundleShortVersion == nil, cachedScore >= 2 {
                    value.bundleShortVersion = value.version
                }
                value.version = better
                cache[key] = value
                persistSnapshot()
            }
        }
        return value
    }

    func load(_ key: String, requiringPackageSize: Bool = false, requiringIcon: Bool = false,
              knownVersion: String? = nil,
              allowCached: @Sendable (VersionMetadata) -> Bool = { _ in true },
              fetch: @Sendable () async throws -> VersionMetadata) async throws -> VersionMetadata {
        // Old records retain their useful version/date, but are refreshed once
        // when an IPA row also needs its size or a legacy dotless version wasn't checked against ticket metadata.
        if let hit = reconciledCachedHit(for: key, requiringPackageSize: requiringPackageSize,
                                         requiringIcon: requiringIcon, knownVersion: knownVersion,
                                         allowCached: allowCached) {
            return hit
        }
        try await acquire()
        defer { release() }
        // A row scrolled away while waiting: skip its request.
        try Task.checkCancellation()
        if let hit = reconciledCachedHit(for: key, requiringPackageSize: requiringPackageSize,
                                         requiringIcon: requiringIcon, knownVersion: knownVersion,
                                         allowCached: allowCached) {
            return hit
        }
        var value = try await fetch()
        let rejectingID = Self.versionID(from: key)
        if let knownVersion {
            let cleanKnown = VersionService.sanitizedVersion(knownVersion, rejectingID: rejectingID)
            if VersionService.versionPreference(cleanKnown, rejectingID: rejectingID) >= 2 {
                if value.bundleShortVersion == nil, VersionService.versionPreference(value.version, rejectingID: rejectingID) >= 1 {
                    value.bundleShortVersion = value.version
                }
                value.version = cleanKnown
            } else {
                value.version = VersionService.preferredVersion(knownVersion, over: value.version, rejectingID: rejectingID)
            }
        }
        if let previous = cache[key] {
            if value.bundleShortVersion == nil { value.bundleShortVersion = previous.bundleShortVersion }
            if value.buildVersion == nil { value.buildVersion = previous.buildVersion }
            if allowCached(previous) {
                value.version = VersionService.preferredVersion(value.version, over: previous.version, rejectingID: rejectingID)
            }
            if !requiringIcon, value.iconAvailable == nil,
               previous.iconAvailable == true,
               FileManager.default.fileExists(atPath: Self.iconURL(key).path) {
                value.iconAvailable = true
            }
        }
        cache[key] = value
        if cache.count > 5_000 { cache.removeAll(); cache[key] = value }
        persistSnapshot()
        return value
    }

    private func acquire() async throws {
        try Task.checkCancellation()
        if inFlight < Self.maxConcurrentFetches {
            inFlight += 1
            return
        }
        let id = UUID()
        try await withTaskCancellationHandler {
            try await withCheckedThrowingContinuation { (continuation: CheckedContinuation<Void, Error>) in
                if Task.isCancelled {
                    continuation.resume(throwing: CancellationError())
                    return
                }
                waiters.append((id, continuation))
            }
        } onCancel: {
            Task { await self.cancelWaiter(id) }
        }
    }
    private func cancelWaiter(_ id: UUID) {
        guard let index = waiters.firstIndex(where: { $0.0 == id }) else { return }
        waiters.remove(at: index).1.resume(throwing: CancellationError())
    }
    private func release() {
        if !waiters.isEmpty {
            waiters.removeFirst().1.resume()
        } else {
            inFlight = max(0, inFlight - 1)
        }
    }
}
