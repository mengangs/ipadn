import ActivityKit
import Combine
import Foundation
import OSLog
import UIKit

private let activityLog = Logger(subsystem: "app.local.iPadn", category: "LiveActivity")

/// Keeps the download Live Activity in step with the download list
/// (Settings › Downloads › Live Activity).
@MainActor
final class DownloadActivity {
    static let shared = DownloadActivity()

    private weak var manager: DownloadManager?
    private var enabled = false
    private var activity: Any?
    private var finishingActivity: Any?
    private var finishingTask: Task<Void, Never>?
    private var subscription: AnyCancellable?
    private var timer: Timer?
    private var lastSent: Any?
    private var lastSentAt = Date.distantPast
    private var lastBgLogAt = Date.distantPast
    private var refreshScheduled = false
    /// The downloads (regular + TestFlight) the activity was showing at the last refresh.
    private var shownKeys = Set<String>()

    var hasActiveActivity: Bool {
        guard #available(iOS 16.2, *), enabled else { return false }
        if let current = activity as? Activity<DownloadActivityAttributes>, current.activityState == .active {
            return true
        }
        return false
    }

    struct ActivityTaskSnapshot: Equatable {
        enum Phase: Equatable { case running, processing, queued, pausing, paused, completed, failed }
        let key: String
        let name: String
        let phase: Phase
        let written: Int64
        let expected: Int64
        let speed: Double
        let waitsForSilentInstall: Bool
    }

    func attach(_ manager: DownloadManager, enabled: Bool) {
        guard #available(iOS 16.2, *), !LocalResources.isPreview else { return }
        self.enabled = enabled
        if self.manager !== manager {
            self.manager = manager
            // One left from an earlier run is picked up rather than duplicated.
            let existing = Activity<DownloadActivityAttributes>.activities
            activity = existing.first
            for old in existing.dropFirst() { Task { await old.end(nil, dismissalPolicy: .immediate) } }
            var publishers: [AnyPublisher<Void, Never>] = [
                manager.$jobs.map { _ in () }.eraseToAnyPublisher(),
                manager.$autoInstalling.map { _ in () }.eraseToAnyPublisher(),
                manager.$autoInstalled.map { _ in () }.eraseToAnyPublisher(),
                manager.$autoInstallFailed.map { _ in () }.eraseToAnyPublisher(),
                manager.$autoInstallCancelled.map { _ in () }.eraseToAnyPublisher(),
                manager.$waitingForWiFi.map { _ in () }.eraseToAnyPublisher(),
                manager.$isLoaded.map { _ in () }.eraseToAnyPublisher(),
            ]
            #if canImport(TestFlightKit)
            publishers.append(TFHomeModel.shared.$activeDownloads.map { _ in () }.eraseToAnyPublisher())
            publishers.append(TFHomeModel.shared.$rows.map { _ in () }.eraseToAnyPublisher())
            #endif
            subscription = Publishers.MergeMany(publishers)
                .sink { [weak self] _ in self?.scheduleRefresh() }
        }
        refresh()
    }

    func sync() {
        guard #available(iOS 16.2, *), !LocalResources.isPreview else { return }
        refresh()
    }

    private func scheduleRefresh() {
        guard !refreshScheduled else { return }
        refreshScheduled = true
        // @Published fires on willSet; scheduling onto the next main turn reads
        // committed state immediately without 300ms debounce lag.
        DispatchQueue.main.async { [weak self] in
            guard let self else { return }
            self.refreshScheduled = false
            self.refresh()
        }
    }

    private func adoptFinishingActivity() {
        guard #available(iOS 16.2, *), activity == nil, let pending = finishingActivity as? Activity<DownloadActivityAttributes> else {
            finishingTask?.cancel(); finishingTask = nil; finishingActivity = nil
            return
        }
        finishingTask?.cancel(); finishingTask = nil; finishingActivity = nil
        if pending.activityState == .active { activity = pending }
    }

    private func endFinishingImmediately() {
        guard #available(iOS 16.2, *) else { return }
        finishingTask?.cancel(); finishingTask = nil
        if let pending = finishingActivity as? Activity<DownloadActivityAttributes> {
            finishingActivity = nil
            Task { await pending.end(nil, dismissalPolicy: .immediate) }
        }
    }

    private func collectSnapshots(manager: DownloadManager, uptime: TimeInterval) -> [ActivityTaskSnapshot] {
        var result: [ActivityTaskSnapshot] = []
        result.reserveCapacity(manager.jobs.count + 4)
        for job in manager.jobs {
            let phase: ActivityTaskSnapshot.Phase
            switch job.status {
            case .running: phase = .running
            case .processing: phase = .processing
            case .queued: phase = .queued
            case .pausing: phase = .pausing
            case .paused: phase = .paused
            case .completed: phase = .completed
            case .failed: phase = .failed
            }
            let bytes = manager.progress(for: job.id).bytes
            let written = bytes?.written ?? job.downloaded
            let expected = max(bytes?.expected ?? 0, job.expected, job.app.size)
            let speed = phase == .running ? (manager.metrics(for: job.id)?.rate(at: uptime) ?? 0) : 0
            result.append(ActivityTaskSnapshot(
                key: "job:" + job.id.uuidString,
                name: job.app.name,
                phase: phase,
                written: written,
                expected: expected,
                speed: speed,
                waitsForSilentInstall: manager.waitsForSilentInstall(job.id)
            ))
        }
        #if canImport(TestFlightKit)
        let tfModel = TFHomeModel.shared
        var seenTF = Set<String>()
        for item in tfModel.activeDownloads {
            seenTF.insert(item.id)
            let state = tfModel.rows[item.id] ?? TFRowState()
            let phase: ActivityTaskSnapshot.Phase
            switch state.stage {
            case .downloading: phase = .running
            case .verifying: phase = .processing
            case .resolving, .installing: phase = .queued
            case .paused: phase = .paused
            case .done: phase = .completed
            case .failed: phase = .failed
            case .idle: continue
            }
            let speed = phase == .running ? (tfModel.metrics(for: item.id)?.rate(at: uptime) ?? 0) : 0
            result.append(ActivityTaskSnapshot(
                key: "tf:" + item.id,
                name: item.displayName,
                phase: phase,
                written: state.received,
                expected: state.total,
                speed: speed,
                waitsForSilentInstall: false
            ))
        }
        for key in shownKeys where key.hasPrefix("tf:") {
            let appID = String(key.dropFirst(3))
            guard !seenTF.contains(appID) else { continue }
            if let outcome = tfModel.recentTerminalOutcome(for: appID) {
                result.append(ActivityTaskSnapshot(
                    key: key,
                    name: outcome.name,
                    phase: outcome.completed ? .completed : .failed,
                    written: outcome.bytes,
                    expected: outcome.bytes,
                    speed: 0,
                    waitsForSilentInstall: outcome.fileURL.map { manager.isExternalSilentInstallPending(fileURL: $0) } ?? false
                ))
            }
        }
        #endif
        return result
    }

    private func refresh() {
        guard #available(iOS 16.2, *), let manager else { return }
        let now = Date()
        let uptime = ProcessInfo.processInfo.systemUptime
        let allSnapshots = collectSnapshots(manager: manager, uptime: uptime)
        let active = allSnapshots.filter { [.running, .pausing, .queued, .processing].contains($0.phase) }
        if !enabled {
            stopTimer()
            endFinishingImmediately()
            lastSent = nil; shownKeys = []; pendingUpdate = nil
            if let current = activity as? Activity<DownloadActivityAttributes> {
                activity = nil
                manager.syncLiveActivityKeepAlive()
                Task { await current.end(nil, dismissalPolicy: .immediate) }
            }
            return
        }
        if !active.isEmpty || manager.autoInstalling != nil { adoptFinishingActivity() }
        if let existing = activity as? Activity<DownloadActivityAttributes>, existing.activityState != .active {
            activity = nil
            lastSent = nil
            pendingUpdate = nil
            manager.syncLiveActivityKeepAlive()
        }
        let current = activity as? Activity<DownloadActivityAttributes>

        // Installing automatically after the download: the same activity follows it.
        if active.isEmpty, let install = manager.autoInstalling {
            let state = Self.autoInstallState(for: install, now: now)
            if let current { send(state, to: current) }
            else if UIApplication.shared.applicationState == .active, ActivityAuthorizationInfo().areActivitiesEnabled {
                activity = try? Activity.request(attributes: DownloadActivityAttributes(),
                                                 content: ActivityContent(state: state, staleDate: Self.staleDate(state)))
                lastSent = state; lastSentAt = now
                manager.syncLiveActivityKeepAlive()
            }
            startTimer()
            return
        }
        if active.isEmpty, let current, manager.autoInstallCancelled != nil,
           (lastSent as? DownloadActivityAttributes.ContentState)?.phase == 4 || current.content.state.phase == 4 {
            stopTimer()
            activity = nil; lastSent = nil; shownKeys = []; pendingUpdate = nil
            manager.syncLiveActivityKeepAlive()
            Task { await current.end(nil, dismissalPolicy: .immediate) }
            return
        }
        // The install did not finish: say so and end with it, rather than stay on "Installing".
        if active.isEmpty, let current, let failed = manager.autoInstallFailed,
           (lastSent as? DownloadActivityAttributes.ContentState)?.phase == 4 || current.content.state.phase == 4 {
            stopTimer()
            activity = nil; lastSent = nil; shownKeys = []; pendingUpdate = nil
            manager.syncLiveActivityKeepAlive()
            finish(current, with: DownloadActivityAttributes.ContentState(phase: 6, name: failed, count: 0, written: 0, expected: 0,
                                                                          updated: now, estimatedEnd: nil, speed: 0))
            return
        }
        let shownSnapshots = allSnapshots.filter { shownKeys.contains($0.key) }
        if active.isEmpty, let current, let installed = manager.autoInstalled,
           ((lastSent as? DownloadActivityAttributes.ContentState)?.phase == 4 || current.content.state.phase == 4
            || shownSnapshots.contains(where: \.waitsForSilentInstall)) {
            stopTimer()
            activity = nil; lastSent = nil; shownKeys = []; pendingUpdate = nil
            manager.syncLiveActivityKeepAlive()
            let done = DownloadActivityAttributes.ContentState(phase: 5, name: installed, count: 0, written: 1000, expected: 1000,
                                                               updated: now, estimatedEnd: nil, speed: 0)
            finish(current, with: done)
            return
        }
        if active.isEmpty, !manager.isLoaded {
            if let current, current.content.state.phase == 4 {
                // Clean up an orphaned phase-4 crash/termination leftover immediately on relaunch.
                stopTimer()
                activity = nil; lastSent = nil; shownKeys = []; pendingUpdate = nil
                manager.syncLiveActivityKeepAlive()
                Task { await current.end(nil, dismissalPolicy: .immediate) }
            }
            return
        }
        // Downloaded and about to install silently: keep the activity for the install.
        if active.isEmpty, activity != nil, shownSnapshots.contains(where: \.waitsForSilentInstall) {
            stopTimer()
            return
        }
        if active.isEmpty {
            stopTimer()
            guard let current else { shownKeys = []; return }
            let paused = shownSnapshots.filter { $0.phase == .paused }
            if !paused.isEmpty {
                // Keep the activity alive in paused phase so resuming (even in background) updates smoothly.
                let pausedState = Self.computePausedSnapshotState(paused: paused, now: now)
                send(pausedState, to: current)
                manager.syncLiveActivityKeepAlive()
                return
            }
            activity = nil
            lastSent = nil
            shownKeys = []
            pendingUpdate = nil
            manager.syncLiveActivityKeepAlive()
            let finished = !shownSnapshots.isEmpty && shownSnapshots.allSatisfy { $0.phase == .completed }
            if finished {
                var done = current.content.state
                done.phase = 2; done.count = 0; done.written = max(done.written, done.expected)
                done.updated = now; done.estimatedEnd = nil; done.speed = 0
                finish(current, with: done)
            } else if let failedItem = shownSnapshots.first(where: { $0.phase == .failed }) {
                let failState = DownloadActivityAttributes.ContentState(
                    phase: 8, name: failedItem.name, count: shownSnapshots.filter { $0.phase == .failed }.count,
                    written: 0, expected: 0, updated: now, estimatedEnd: nil, speed: 0)
                finish(current, with: failState)
            } else {
                Task { await current.end(nil, dismissalPolicy: .immediate) }
            }
            return
        }
        let state = Self.computeSnapshotState(active: active, now: now)
        shownKeys = Set(active.map(\.key))
        if let current {
            send(state, to: current)
        } else if active.contains(where: { $0.phase == .running }),
                  UIApplication.shared.applicationState == .active,
                  ActivityAuthorizationInfo().areActivitiesEnabled {
            // Only the app in front may start one.
            activity = try? Activity.request(attributes: DownloadActivityAttributes(),
                                             content: ActivityContent(state: state, staleDate: Self.staleDate(state)))
            lastSent = state; lastSentAt = now
            manager.syncLiveActivityKeepAlive()
        }
        if state.phase == 7 { stopTimer() } else { startTimer() }
    }

    @available(iOS 16.1, *)
    nonisolated static func computeSnapshotState(
        active: [ActivityTaskSnapshot],
        now: Date = Date()
    ) -> DownloadActivityAttributes.ContentState {
        let running = active.filter { $0.phase == .running }
        let processing = active.filter { $0.phase == .processing }
        let queued = active.filter { $0.phase == .queued }
        let pausing = active.filter { $0.phase == .pausing }
        let phase: Int
        let cohort: [ActivityTaskSnapshot]
        if !running.isEmpty {
            phase = 0; cohort = running
        } else if !processing.isEmpty {
            phase = 1; cohort = processing
        } else if !queued.isEmpty {
            phase = 3; cohort = queued
        } else {
            phase = 7; cohort = pausing
        }
        var written: Int64 = 0, expected: Int64 = 0, speed = 0.0
        for item in cohort {
            written += item.written
            expected += item.expected
            if phase == 0 { speed += item.speed }
        }
        guard let lead = cohort.first else {
            return .init(phase: phase, name: "", count: active.count,
                         written: written, expected: expected, updated: now, estimatedEnd: nil, speed: 0)
        }
        let left = Double(max(0, expected - written))
        let end = phase == 0 && speed > 1024 && left > 0 ? now.addingTimeInterval(left / speed) : nil
        let speedBytes = phase == 0 && speed > 0 ? Int64(min(speed.rounded(), Double(Int64.max / 2))) : 0
        return .init(phase: phase, name: lead.name, count: active.count,
                     written: written, expected: expected, updated: now, estimatedEnd: end, speed: speedBytes)
    }

    @available(iOS 16.1, *)
    nonisolated static func computePausedSnapshotState(
        paused: [ActivityTaskSnapshot],
        now: Date = Date()
    ) -> DownloadActivityAttributes.ContentState {
        var written: Int64 = 0, expected: Int64 = 0
        for item in paused {
            written += item.written
            expected += item.expected
        }
        return .init(phase: 7, name: paused.first?.name ?? "", count: paused.count,
                     written: written, expected: expected, updated: now, estimatedEnd: nil, speed: 0)
    }

    @available(iOS 16.1, *)
    nonisolated static func computeState(
        active: [DownloadJob],
        progress: (DownloadJob) -> (written: Int64, expected: Int64),
        rate: (UUID) -> Double,
        now: Date = Date()
    ) -> DownloadActivityAttributes.ContentState {
        let snapshots = active.map { job -> ActivityTaskSnapshot in
            let p = progress(job)
            let phase: ActivityTaskSnapshot.Phase = switch job.status {
            case .running: .running
            case .processing: .processing
            case .queued: .queued
            case .pausing: .pausing
            case .paused: .paused
            case .completed: .completed
            case .failed: .failed
            }
            return ActivityTaskSnapshot(
                key: "job:" + job.id.uuidString,
                name: job.app.name,
                phase: phase,
                written: p.written,
                expected: p.expected,
                speed: phase == .running ? rate(job.id) : 0,
                waitsForSilentInstall: false
            )
        }
        return computeSnapshotState(active: snapshots, now: now)
    }

    @available(iOS 16.1, *)
    nonisolated static func computePausedState(
        paused: [DownloadJob],
        progress: (UUID) -> (written: Int64, expected: Int64),
        now: Date = Date()
    ) -> DownloadActivityAttributes.ContentState {
        let snapshots = paused.map { job -> ActivityTaskSnapshot in
            let p = progress(job.id)
            return ActivityTaskSnapshot(
                key: "job:" + job.id.uuidString,
                name: job.app.name,
                phase: .paused,
                written: p.written,
                expected: p.expected,
                speed: 0,
                waitsForSilentInstall: false
            )
        }
        return computePausedSnapshotState(paused: snapshots, now: now)
    }

    @available(iOS 16.1, *)
    nonisolated static func autoInstallState(
        for install: DownloadManager.AutoInstallProgress,
        now: Date = Date()
    ) -> DownloadActivityAttributes.ContentState {
        let speedStage: Int64 = install.stage == .installing || !install.canCancel ? 2 : install.stage == .uploading ? 1 : 0
        guard install.hasProgress || speedStage == 2 else {
            return .init(phase: 4, name: install.name, count: 1, written: 0, expected: 0,
                         updated: now, estimatedEnd: nil, speed: speedStage)
        }
        let scaled = Int64((install.fraction * 1000).rounded())
        let written = speedStage == 2 ? min(1000, max(700, scaled)) : min(1000, max(10, scaled))
        return .init(phase: 4, name: install.name, count: 1, written: written, expected: 1000,
                     updated: now, estimatedEnd: nil, speed: speedStage)
    }

    @available(iOS 16.1, *)
    nonisolated static func shouldSend(
        _ state: DownloadActivityAttributes.ContentState,
        after last: DownloadActivityAttributes.ContentState?,
        elapsed: TimeInterval,
        inBackground: Bool = false
    ) -> Bool {
        guard let last else { return true }
        let changed = last.phase != state.phase
            || last.name != state.name
            || last.count != state.count
            || (last.estimatedEnd == nil) != (state.estimatedEnd == nil)
            || (state.phase == 4 && (last.speed != state.speed || (last.expected > 0) != (state.expected > 0)))
        if changed { return true }
        if inBackground {
            let lastPercent = last.expected > 0
                ? Int((min(1, max(0, Double(last.written) / Double(last.expected))) * 100).rounded())
                : -1
            let nextPercent = state.expected > 0
                ? Int((min(1, max(0, Double(state.written) / Double(state.expected))) * 100).rounded())
                : -1
            if nextPercent != lastPercent {
                let minGap: TimeInterval = abs(nextPercent - lastPercent) >= 3 ? 1.0 : 2.0
                return elapsed >= minGap
            }
            if state.phase == 4 && elapsed >= 60 { return true }
            if (last.written != state.written || last.expected != state.expected) && elapsed >= 5.0 {
                return true
            }
            if let prevEnd = last.estimatedEnd, let nextEnd = state.estimatedEnd,
               abs(nextEnd.timeIntervalSince(prevEnd)) >= 5, elapsed >= 5.0 {
                return true
            }
            return false
        }
        guard elapsed >= 1 else { return false }
        let moved = last.written != state.written || last.expected != state.expected
        if moved { return true }
        if state.phase == 4 && elapsed >= 60 { return true }
        if let prevEnd = last.estimatedEnd, let nextEnd = state.estimatedEnd,
           abs(nextEnd.timeIntervalSince(prevEnd)) >= 3 {
            return true
        }
        if abs(state.speed - last.speed) >= max(32_768, last.speed / 4) {
            return true
        }
        return false
    }

    @available(iOS 16.2, *)
    private struct PendingUpdate {
        let activity: Activity<DownloadActivityAttributes>
        let state: DownloadActivityAttributes.ContentState
        let alert: AlertConfiguration?
    }

    private var updatePumpTask: Task<Void, Never>?
    private var pendingUpdate: Any?

    /// Changes of phase, app, count or ETA availability go out at once; progress coalesces cleanly.
    @available(iOS 16.2, *)
    private func send(_ state: DownloadActivityAttributes.ContentState, to activity: Activity<DownloadActivityAttributes>) {
        let last = lastSent as? DownloadActivityAttributes.ContentState
        let now = Date()
        let inBackground = UIApplication.shared.applicationState != .active
        guard Self.shouldSend(state, after: last, elapsed: now.timeIntervalSince(lastSentAt), inBackground: inBackground) else { return }
        let phaseChanged = last == nil || last!.phase != state.phase || last!.name != state.name || last!.count != state.count
        lastSent = state; lastSentAt = now
        if phaseChanged {
            activityLog.notice("LA update phase \(state.phase) \(state.name, privacy: .public) bg=\(inBackground)")
        } else if inBackground, now.timeIntervalSince(lastBgLogAt) >= 10 {
            lastBgLogAt = now
            let pct = state.expected > 0 ? Int((min(1, max(0, Double(state.written) / Double(state.expected))) * 100).rounded()) : 0
            activityLog.notice("LA bg progress phase=\(state.phase) pct=\(pct)% state=\(String(describing: activity.activityState), privacy: .public)")
        }
        // Starting to install: the Dynamic Island opens briefly to say so.
        let alert = phaseChanged && state.phase == 4 && last?.phase != 4 ? Self.alert(state) : nil
        let priorAlert = (pendingUpdate as? PendingUpdate)?.alert
        pendingUpdate = PendingUpdate(activity: activity, state: state, alert: alert ?? priorAlert)
        startUpdatePumpIfNeeded()
    }

    @available(iOS 16.2, *)
    private func startUpdatePumpIfNeeded() {
        guard updatePumpTask == nil else { return }
        updatePumpTask = Task { @MainActor [weak self] in
            defer { self?.updatePumpTask = nil }
            while let self, let next = self.pendingUpdate as? PendingUpdate {
                self.pendingUpdate = nil
                guard next.activity.activityState == .active else { continue }
                await next.activity.update(
                    ActivityContent(state: next.state, staleDate: Self.staleDate(next.state)),
                    alertConfiguration: next.alert
                )
            }
        }
    }

    /// Shows the final state (downloaded, installed, failed) for a
    /// moment, then ends the activity together with the task.
    @available(iOS 16.2, *)
    private func finish(_ activity: Activity<DownloadActivityAttributes>, with state: DownloadActivityAttributes.ContentState) {
        finishingTask?.cancel()
        pendingUpdate = nil
        let priorPump = updatePumpTask
        finishingActivity = activity
        let task = BackgroundTime()
        activityLog.notice("LA finish phase \(state.phase) bg=\(UIApplication.shared.applicationState != .active)")
        finishingTask = Task { [weak self] in
            defer { task.end() }
            await priorPump?.value
            await activity.update(ActivityContent(state: state, staleDate: nil))
            do { try await Task.sleep(nanoseconds: 2_000_000_000) }
            catch { return }
            guard !Task.isCancelled else { return }
            if (self?.finishingActivity as? Activity<DownloadActivityAttributes>)?.id == activity.id {
                self?.finishingActivity = nil
                self?.finishingTask = nil
            }
            await activity.end(ActivityContent(state: state, staleDate: nil), dismissalPolicy: .immediate)
        }
    }

    /// Updates come every few seconds while iPadn runs; much later, it no longer does.
    @available(iOS 16.2, *)
    private static func staleDate(_ state: DownloadActivityAttributes.ContentState) -> Date? {
        if state.phase == 4 { return Date().addingTimeInterval(180) }
        return [0, 1].contains(state.phase) ? Date().addingTimeInterval(90) : nil
    }

    @available(iOS 16.2, *)
    private static func alert(_ state: DownloadActivityAttributes.ContentState) -> AlertConfiguration {
        let title: LocalizedStringResource = switch state.phase {
        case 2: "下载完成"
        case 4: "正在安装"
        case 6: "安装未完成"
        case 8: "下载失败"
        default: "已安装"
        }
        return AlertConfiguration(title: title, body: LocalizedStringResource(String.LocalizationValue(state.name)), sound: .default)
    }

    private func startTimer() {
        guard activity != nil, timer == nil else { return }
        let timer = Timer(timeInterval: 1, repeats: true) { [weak self] _ in
            MainActor.assumeIsolated { self?.refresh() }
        }
        RunLoop.main.add(timer, forMode: .common)
        self.timer = timer
    }

    private func stopTimer() { timer?.invalidate(); timer = nil }
}


/// A little time in the background to finish what was started.
@MainActor
private final class BackgroundTime {
    private var id = UIBackgroundTaskIdentifier.invalid
    init() { id = UIApplication.shared.beginBackgroundTask { [weak self] in self?.end() } }
    func end() {
        guard id != .invalid else { return }
        UIApplication.shared.endBackgroundTask(id); id = .invalid
    }
}
